package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.SupplierEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PharmacyViewModel

@Composable
fun SupplierLedgerScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()

    var showAddSupplierDialog by remember { mutableStateOf(false) }
    var supplierToPayDue by remember { mutableStateOf<SupplierEntity?>(null) }
    var supplierToEdit by remember { mutableStateOf<SupplierEntity?>(null) }
    var supplierToDelete by remember { mutableStateOf<SupplierEntity?>(null) }

    val filteredSuppliers = remember(suppliers, viewModel.supplierSearchQuery) {
        suppliers.filter { supp ->
            viewModel.supplierSearchQuery.isBlank() ||
                    supp.companyName.contains(viewModel.supplierSearchQuery, ignoreCase = true) ||
                    supp.representativeName.contains(viewModel.supplierSearchQuery, ignoreCase = true) ||
                    supp.phone.contains(viewModel.supplierSearchQuery, ignoreCase = true)
        }
    }

    val totalSupplierDue = suppliers.sumOf { it.currentDue }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    supplierToEdit = null
                    showAddSupplierDialog = true
                },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.AddBusiness, contentDescription = "Add Supplier")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("নতুন সাপ্লায়ার / কোম্পানি", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = viewModel.supplierSearchQuery,
                onValueChange = { viewModel.supplierSearchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                placeholder = { Text("কোম্পানি, ডিপো বা প্রতিনিধির নাম খুঁজুন...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary)
                },
                trailingIcon = {
                    if (viewModel.supplierSearchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.supplierSearchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Supplier Due Summary Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = AmberWarningContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "মোট সাপ্লায়ার / কোম্পানি বকেয়া",
                            style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
                        )
                        Text(
                            text = formatCurrency(totalSupplierDue),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = AmberWarning
                            )
                        )
                    }
                    Surface(
                        color = Color.White.copy(alpha = 0.8f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "${suppliers.size} টি ওষুধ কোম্পানি/ডিপো",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                        )
                    }
                }
            }

            if (filteredSuppliers.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.LocalShipping,
                    title = "কোন সাপ্লায়ার পাওয়া যায়নি",
                    description = "নতুন ওষুধ কোম্পানি বা ডিপো যুক্ত করতে নিচের বাটনে চাপুন।"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredSuppliers, key = { it.id }) { supplier ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(AmberWarningContainer),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.LocalShipping,
                                                contentDescription = null,
                                                tint = AmberWarning,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = supplier.companyName,
                                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                            )
                                            if (supplier.representativeName.isNotBlank()) {
                                                Text(
                                                    text = "প্রতিনিধি: ${supplier.representativeName}",
                                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                                )
                                            }
                                            if (supplier.phone.isNotBlank()) {
                                                Text(
                                                    text = "📱 ${supplier.phone}",
                                                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                                )
                                            }
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        if (supplier.currentDue > 0) {
                                            Text(
                                                text = "বাকি: " + formatCurrency(supplier.currentDue),
                                                style = MaterialTheme.typography.titleSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = AmberWarning
                                                )
                                            )
                                        } else {
                                            Text(
                                                text = "কোন বকেয়া নেই",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = GreenSuccess,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            )
                                        }
                                        Text(
                                            text = "মোট ক্রয়: ${formatCurrency(supplier.totalPurchased)}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                        )
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = DividerColor)

                                // Actions (Call, Pay Due, Edit, Delete)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (supplier.phone.isNotBlank()) {
                                            FilledTonalIconButton(
                                                onClick = {
                                                    val callIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${supplier.phone}"))
                                                    context.startActivity(callIntent)
                                                },
                                                modifier = Modifier.size(34.dp),
                                                shape = CircleShape
                                            ) {
                                                Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                                            }
                                        }

                                        IconButton(onClick = {
                                            supplierToEdit = supplier
                                            showAddSupplierDialog = true
                                        }, modifier = Modifier.size(34.dp)) {
                                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                        }

                                        IconButton(onClick = {
                                            supplierToDelete = supplier
                                        }, modifier = Modifier.size(34.dp)) {
                                            Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete", tint = RedAlert, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    if (supplier.currentDue > 0) {
                                        Button(
                                            onClick = { supplierToPayDue = supplier },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = AmberWarning)
                                        ) {
                                            Icon(imageVector = Icons.Default.Payment, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("বাকি পরিশোধ", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Add / Edit Supplier Dialog
    if (showAddSupplierDialog) {
        AddSupplierDialog(
            initialSupplier = supplierToEdit,
            onDismiss = {
                showAddSupplierDialog = false
                supplierToEdit = null
            },
            onSave = { supp ->
                viewModel.saveSupplier(supp)
            }
        )
    }

    // Pay Supplier Due Dialog
    if (supplierToPayDue != null) {
        val supp = supplierToPayDue!!
        CollectDueDialog(
            partyName = supp.companyName,
            currentDue = supp.currentDue,
            isCustomer = false,
            onDismiss = { supplierToPayDue = null },
            onConfirm = { amount, note ->
                viewModel.paySupplierDue(supp.id, amount, supp.companyName, note)
                supplierToPayDue = null
            }
        )
    }

    // Delete confirmation
    if (supplierToDelete != null) {
        AlertDialog(
            onDismissRequest = { supplierToDelete = null },
            title = { Text("সাপ্লায়ার মুছে ফেলতে চান?") },
            text = { Text("${supplierToDelete?.companyName}-কে তালিকা থেকে মুছে ফেলা হবে।") },
            confirmButton = {
                Button(
                    onClick = {
                        supplierToDelete?.let { viewModel.deleteSupplier(it) }
                        supplierToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedAlert)
                ) {
                    Text("মুছে ফেলুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { supplierToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
private fun AddSupplierDialog(
    initialSupplier: SupplierEntity? = null,
    onDismiss: () -> Unit,
    onSave: (SupplierEntity) -> Unit
) {
    var companyName by remember { mutableStateOf(initialSupplier?.companyName ?: "") }
    var representativeName by remember { mutableStateOf(initialSupplier?.representativeName ?: "") }
    var phone by remember { mutableStateOf(initialSupplier?.phone ?: "") }
    var address by remember { mutableStateOf(initialSupplier?.address ?: "") }
    var openingDueText by remember { mutableStateOf(initialSupplier?.currentDue?.toString() ?: "0.0") }
    var error by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(imageVector = Icons.Default.AddBusiness, contentDescription = null, tint = EmeraldPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (initialSupplier == null) "নতুন কোম্পানি / সাপ্লায়ার" else "সাপ্লায়ার তথ্য সংশোধন",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                if (error != null) {
                    Text(error ?: "", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.bodySmall)
                }

                OutlinedTextField(
                    value = companyName,
                    onValueChange = { companyName = it; error = null },
                    label = { Text("কোম্পানি / এজেন্সির নাম *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = representativeName,
                    onValueChange = { representativeName = it },
                    label = { Text("প্রতিনিধি / MPO নাম") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = phone,
                    onValueChange = { phone = it },
                    label = { Text("মোবাইল নম্বর") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = address,
                    onValueChange = { address = it },
                    label = { Text("ঠিকানা / ডিপো লোকেশন") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                if (initialSupplier == null) {
                    OutlinedTextField(
                        value = openingDueText,
                        onValueChange = { openingDueText = it },
                        label = { Text("পূর্বের বকেয়া পাওনা (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                        Text("বাতিল")
                    }

                    Button(
                        onClick = {
                            if (companyName.isBlank()) {
                                error = "কোম্পানির নাম প্রদান করুন।"
                                return@Button
                            }
                            val openingDue = openingDueText.toDoubleOrNull() ?: 0.0
                            val supplier = (initialSupplier ?: SupplierEntity(
                                companyName = companyName.trim(),
                                representativeName = representativeName.trim(),
                                phone = phone.trim(),
                                address = address.trim(),
                                currentDue = openingDue
                            )).copy(
                                companyName = companyName.trim(),
                                representativeName = representativeName.trim(),
                                phone = phone.trim(),
                                address = address.trim()
                            )
                            onSave(supplier)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1.3f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("সংরক্ষণ করুন")
                    }
                }
            }
        }
    }
}
