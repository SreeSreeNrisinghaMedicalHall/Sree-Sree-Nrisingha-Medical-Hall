package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CashTransactionEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PharmacyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AccountingScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val transactions by viewModel.cashTransactions.collectAsStateWithLifecycle()
    var showAddExpenseDialog by remember { mutableStateOf(false) }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, INCOME, EXPENSE

    val totalIncome = transactions.filter { it.type.startsWith("INCOME") || it.type == "OTHER_INCOME" }.sumOf { it.amount }
    val totalExpense = transactions.filter { it.type.startsWith("EXPENSE") || it.type == "OTHER_EXPENSE" }.sumOf { it.amount }
    val netCashInHand = (totalIncome - totalExpense).coerceAtLeast(0.0)

    val filteredTransactions = remember(transactions, selectedFilter) {
        when (selectedFilter) {
            "INCOME" -> transactions.filter { it.type.startsWith("INCOME") || it.type == "OTHER_INCOME" }
            "EXPENSE" -> transactions.filter { it.type.startsWith("EXPENSE") || it.type == "OTHER_EXPENSE" }
            else -> transactions
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddExpenseDialog = true },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.AddCard, contentDescription = "Add Expense/Income")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("আয় / ব্যয় এন্ট্রি", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Cash Balance Summary Hero
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = CyanAccentContainer)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "হাতের নগদ (Cash in Drawer)",
                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium, color = TextSecondary)
                        )
                        Icon(
                            imageVector = Icons.Default.AccountBalanceWallet,
                            contentDescription = null,
                            tint = CyanAccent,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = formatCurrency(netCashInHand),
                        style = MaterialTheme.typography.headlineMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = CyanAccent,
                            fontSize = 28.sp
                        )
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = DividerColor)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column {
                            Text(
                                text = "মোট নগদ জমা (+)",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                            )
                            Text(
                                text = formatCurrency(totalIncome),
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = GreenSuccess
                                )
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = "মোট নগদ খরচ (-)",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                            )
                            Text(
                                text = formatCurrency(totalExpense),
                                style = MaterialTheme.typography.bodyLarge.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = RedAlert
                                )
                            )
                        }
                    }
                }
            }

            // Filter Tabs
            PrimaryTabRow(
                selectedTabIndex = when (selectedFilter) {
                    "INCOME" -> 1
                    "EXPENSE" -> 2
                    else -> 0
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                containerColor = Color.Transparent,
                divider = {}
            ) {
                Tab(
                    selected = selectedFilter == "ALL",
                    onClick = { selectedFilter = "ALL" },
                    text = { Text("সব লেনদেন (${transactions.size})") }
                )
                Tab(
                    selected = selectedFilter == "INCOME",
                    onClick = { selectedFilter = "INCOME" },
                    text = { Text("জমা / আয় (+)") }
                )
                Tab(
                    selected = selectedFilter == "EXPENSE",
                    onClick = { selectedFilter = "EXPENSE" },
                    text = { Text("ব্যয় / খরচ (-)") }
                )
            }

            // Transactions Stream
            if (filteredTransactions.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.ReceiptLong,
                    title = "কোন ক্যাশ লেনদেন পাওয়া যায়নি",
                    description = "নতুন খরচ বা আয় যোগ করতে নিচের বাটনে চাপুন।"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(8.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredTransactions, key = { it.id }) { tx ->
                        val isIncome = tx.type.startsWith("INCOME") || tx.type == "OTHER_INCOME"
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(12.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(38.dp)
                                            .clip(CircleShape)
                                            .background(if (isIncome) GreenSuccessContainer else RedAlertContainer),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Icon(
                                            imageVector = if (isIncome) Icons.Default.ArrowDownward else Icons.Default.ArrowUpward,
                                            contentDescription = null,
                                            tint = if (isIncome) GreenSuccess else RedAlert,
                                            modifier = Modifier.size(20.dp)
                                        )
                                    }
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column {
                                        Text(
                                            text = tx.title,
                                            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "${tx.category} • ${formatDate(tx.timestamp)}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                        )
                                        if (tx.note.isNotBlank()) {
                                            Text(
                                                text = tx.note,
                                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                                                maxLines = 1
                                            )
                                        }
                                    }
                                }

                                Text(
                                    text = (if (isIncome) "+ " else "- ") + formatCurrency(tx.amount),
                                    style = MaterialTheme.typography.titleMedium.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = if (isIncome) GreenSuccess else RedAlert
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddExpenseDialog) {
        AddExpenseDialog(
            onDismiss = { showAddExpenseDialog = false },
            onSaveExpense = { cat, amt, title, note ->
                viewModel.recordExpense(cat, amt, title, note)
            },
            onSaveIncome = { cat, amt, title, note ->
                viewModel.recordIncome(cat, amt, title, note)
            }
        )
    }
}
