package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.MedicineEntity
import com.example.data.SampleData
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PharmacyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MedicineListScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val medicines by viewModel.medicines.collectAsStateWithLifecycle()

    var showAddEditDialog by remember { mutableStateOf(false) }
    var selectedMedicineToEdit by remember { mutableStateOf<MedicineEntity?>(null) }
    var medicineToDelete by remember { mutableStateOf<MedicineEntity?>(null) }

    // Filter Logic
    val filteredMedicines = remember(
        medicines,
        viewModel.medicineSearchQuery,
        viewModel.selectedCategoryFilter,
        viewModel.stockTabFilter
    ) {
        medicines.filter { med ->
            val matchQuery = viewModel.medicineSearchQuery.isBlank() ||
                    med.name.contains(viewModel.medicineSearchQuery, ignoreCase = true) ||
                    med.genericName.contains(viewModel.medicineSearchQuery, ignoreCase = true) ||
                    med.company.contains(viewModel.medicineSearchQuery, ignoreCase = true) ||
                    med.barcode.contains(viewModel.medicineSearchQuery, ignoreCase = true)

            val matchCategory = viewModel.selectedCategoryFilter == "All" ||
                    med.category.equals(viewModel.selectedCategoryFilter, ignoreCase = true)

            val matchStockTab = when (viewModel.stockTabFilter) {
                "LOW_STOCK" -> med.stockQuantity <= med.minStockAlert
                "EXPIRING_SOON" -> viewModel.isMedicineExpiringSoon(med.expiryDate)
                "EXPIRED" -> viewModel.isMedicineExpired(med.expiryDate)
                else -> true
            }

            matchQuery && matchCategory && matchStockTab
        }
    }

    val totalPurchaseValue = medicines.sumOf { it.purchasePrice * it.stockQuantity }
    val totalMrpValue = medicines.sumOf { it.mrpPrice * it.stockQuantity }
    val lowStockCount = medicines.count { it.stockQuantity <= it.minStockAlert }
    val expiringCount = medicines.count { viewModel.isMedicineExpiringSoon(it.expiryDate) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    selectedMedicineToEdit = null
                    showAddEditDialog = true
                },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Add Medicine")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("নতুন ঔষধ যোগ", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = viewModel.medicineSearchQuery,
                onValueChange = { viewModel.medicineSearchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                placeholder = { Text("ঔষধের নাম, জেনেরিক বা কোম্পানি দিয়ে খুঁজুন...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary)
                },
                trailingIcon = {
                    if (viewModel.medicineSearchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.medicineSearchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Stock Filter Tabs (All, Low Stock, Expiring)
            PrimaryTabRow(
                selectedTabIndex = when (viewModel.stockTabFilter) {
                    "LOW_STOCK" -> 1
                    "EXPIRING_SOON" -> 2
                    "EXPIRED" -> 3
                    else -> 0
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 8.dp),
                containerColor = Color.Transparent,
                divider = {}
            ) {
                Tab(
                    selected = viewModel.stockTabFilter == "ALL",
                    onClick = { viewModel.stockTabFilter = "ALL" },
                    text = { Text("সকল (${medicines.size})", fontSize = 13.sp) }
                )
                Tab(
                    selected = viewModel.stockTabFilter == "LOW_STOCK",
                    onClick = { viewModel.stockTabFilter = "LOW_STOCK" },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("কম স্টক", fontSize = 13.sp)
                            if (lowStockCount > 0) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(
                                    color = AmberWarningContainer,
                                    shape = CircleShape
                                ) {
                                    Text(
                                        text = "$lowStockCount",
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = AmberWarning,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                )
                Tab(
                    selected = viewModel.stockTabFilter == "EXPIRING_SOON",
                    onClick = { viewModel.stockTabFilter = "EXPIRING_SOON" },
                    text = {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text("মেয়াদ হ্রাস", fontSize = 13.sp)
                            if (expiringCount > 0) {
                                Spacer(modifier = Modifier.width(4.dp))
                                Surface(
                                    color = RedAlertContainer,
                                    shape = CircleShape
                                ) {
                                    Text(
                                        text = "$expiringCount",
                                        modifier = Modifier.padding(horizontal = 5.dp, vertical = 1.dp),
                                        style = MaterialTheme.typography.labelSmall.copy(
                                            color = RedAlert,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 10.sp
                                        )
                                    )
                                }
                            }
                        }
                    }
                )
            }

            // Category Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(SampleData.medicineCategories) { cat ->
                    FilterChip(
                        selected = viewModel.selectedCategoryFilter == cat,
                        onClick = { viewModel.selectedCategoryFilter = cat },
                        label = { Text(cat, fontSize = 12.sp) }
                    )
                }
            }

            // Valuation Bar
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCardAlt)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "মোট স্টক মূল্য (MRP): ${formatCurrency(totalMrpValue)}",
                        style = MaterialTheme.typography.labelMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = EmeraldDark
                        )
                    )
                    Text(
                        text = "ক্রয়মূল্য: ${formatCurrency(totalPurchaseValue)}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                    )
                }
            }

            // Medicine List
            if (filteredMedicines.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.Medication,
                    title = "কোন ঔষধ খুঁজে পাওয়া যায়নি",
                    description = "নতুন ঔষধ যুক্ত করতে নিচের বাটনে ট্যাপ করুন।"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredMedicines, key = { it.id }) { medicine ->
                        MedicineDetailCard(
                            medicine = medicine,
                            isExpiring = viewModel.isMedicineExpiringSoon(medicine.expiryDate),
                            isExpired = viewModel.isMedicineExpired(medicine.expiryDate),
                            onEdit = {
                                selectedMedicineToEdit = medicine
                                showAddEditDialog = true
                            },
                            onDelete = {
                                medicineToDelete = medicine
                            }
                        )
                    }
                }
            }
        }
    }

    // Add / Edit Medicine Dialog
    if (showAddEditDialog) {
        AddEditMedicineDialog(
            initialMedicine = selectedMedicineToEdit,
            onDismiss = {
                showAddEditDialog = false
                selectedMedicineToEdit = null
            },
            onSave = { updatedMed ->
                viewModel.saveMedicine(updatedMed)
            }
        )
    }

    // Delete Confirmation Dialog
    if (medicineToDelete != null) {
        AlertDialog(
            onDismissRequest = { medicineToDelete = null },
            title = { Text("ঔষধ মুছে ফেলতে চান?") },
            text = { Text("${medicineToDelete?.name} ডাটাবেজ থেকে মুছে ফেলা হবে।") },
            confirmButton = {
                Button(
                    onClick = {
                        medicineToDelete?.let { viewModel.deleteMedicine(it) }
                        medicineToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedAlert)
                ) {
                    Text("মুছে ফেলুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { medicineToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
private fun MedicineDetailCard(
    medicine: MedicineEntity,
    isExpiring: Boolean,
    isExpired: Boolean,
    onEdit: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp)
        ) {
            // Header Row: Name + Category + Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = medicine.name,
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = CyanAccentContainer,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = medicine.category,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = CyanAccent,
                                fontWeight = FontWeight.SemiBold
                            )
                        )
                    }
                }

                Row {
                    IconButton(onClick = onEdit, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = EmeraldPrimary, modifier = Modifier.size(18.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete", tint = RedAlert, modifier = Modifier.size(18.dp))
                    }
                }
            }

            // Generic Name
            if (medicine.genericName.isNotBlank()) {
                Text(
                    text = "Generic: ${medicine.genericName}",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary, fontWeight = FontWeight.Medium)
                )
            }

            // Company & Strength
            Text(
                text = "${medicine.company} • ${medicine.strength}",
                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
            )

            HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = DividerColor)

            // Price & Stock Grid
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "বিক্রয়মূল্য (MRP): ${formatCurrency(medicine.mrpPrice)}",
                        style = MaterialTheme.typography.bodyMedium.copy(
                            fontWeight = FontWeight.Bold,
                            color = EmeraldDark
                        )
                    )
                    Text(
                        text = "ক্রয়মূল্য: ${formatCurrency(medicine.purchasePrice)} • একক: ${medicine.unit}",
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                    )
                }

                Column(horizontalAlignment = Alignment.End) {
                    StockBadge(quantity = medicine.stockQuantity, minThreshold = medicine.minStockAlert)
                    if (medicine.shelfLocation.isNotBlank()) {
                        Text(
                            text = "র্যাক: ${medicine.shelfLocation}",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary, fontSize = 11.sp),
                            modifier = Modifier.padding(top = 2.dp)
                        )
                    }
                }
            }

            // Batch & Expiry Tag
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text(
                    text = "ব্যাচ: ${medicine.batchNumber}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                )

                val expiryColor = when {
                    isExpired -> RedAlert
                    isExpiring -> AmberWarning
                    else -> TextTertiary
                }
                val expiryText = when {
                    isExpired -> "⚠️ মেয়াদোত্তীর্ণ (${medicine.expiryDate})"
                    isExpiring -> "⚠️ মেয়াদ শেষ হচ্ছে (${medicine.expiryDate})"
                    else -> "মেয়াদ: ${medicine.expiryDate}"
                }

                Text(
                    text = expiryText,
                    style = MaterialTheme.typography.labelSmall.copy(
                        color = expiryColor,
                        fontWeight = if (isExpired || isExpiring) FontWeight.Bold else FontWeight.Normal
                    )
                )
            }
        }
    }
}
