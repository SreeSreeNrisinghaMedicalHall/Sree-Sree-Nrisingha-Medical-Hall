package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Clean Minimalism Pharmacy Palette
val PharmacyGreenPrimary = Color(0xFF006C4C)
val PharmacyGreenDark = Color(0xFF003926)
val PharmacyGreenLight = Color(0xFF338B6B)
val PharmacyGreenContainer = Color(0xFFD1EAD3)
val OnPharmacyGreenContainer = Color(0xFF003926)
val PharmacyGreenBorder = Color(0xFFB7D6B9)

// Metric & Pastel Containers
val MintCardBackground = Color(0xFFD1EAD3)
val MintCardBorder = Color(0xFFB7D6B9)
val MintCardText = Color(0xFF003926)

val CoralCardBackground = Color(0xFFFFDBCB)
val CoralCardBorder = Color(0xFFF2BCA7)
val CoralCardText = Color(0xFF3D0F00)

val DarkAlertBackground = Color(0xFF1D1B1E)
val DarkAlertPill = Color(0xFFEADDFF)
val DarkAlertPillText = Color(0xFF21005D)

// Quick Action Pastel Backgrounds
val PastelGreen = Color(0xFFE8F5E9)
val PastelBlue = Color(0xFFE3F2FD)
val PastelOrange = Color(0xFFFFF3E0)
val PastelPurple = Color(0xFFF3E5F5)
val PastelTeal = Color(0xFFE0F2F1)
val PastelRed = Color(0xFFFFEBEE)

// Status & Accents
val CyanAccent = Color(0xFF006C4C)
val CyanAccentContainer = Color(0xFFE0F2F1)
val AmberWarning = Color(0xFFC05621)
val AmberWarningContainer = Color(0xFFFFF3E0)
val RedAlert = Color(0xFFBA1A1A)
val RedAlertContainer = Color(0xFFFFEBEE)
val GreenSuccess = Color(0xFF006C4C)
val GreenSuccessContainer = Color(0xFFD1EAD3)

// Base Backgrounds & Surfaces (Clean Minimalism #F7F9F2)
val SlateBackground = Color(0xFFF7F9F2)
val SurfaceCard = Color(0xFFFFFFFF)
val SurfaceCardAlt = Color(0xFFF1F5EB)
val CardBorderColor = Color(0xFFE2E8F0)

val TextPrimary = Color(0xFF191C1B)
val TextSecondary = Color(0xFF49454F)
val TextTertiary = Color(0xFF79747E)
val DividerColor = Color(0xFFE6EAE4)

// Legacy alias compatibility
val EmeraldPrimary = PharmacyGreenPrimary
val EmeraldDark = PharmacyGreenDark
val EmeraldContainer = PharmacyGreenContainer
val OnEmeraldContainer = OnPharmacyGreenContainer

// Dark Theme Variants
val DarkBackground = Color(0xFF111413)
val DarkSurface = Color(0xFF191C1B)
val DarkSurfaceAlt = Color(0xFF222625)
val DarkPrimary = Color(0xFF70DBAC)
val DarkPrimaryContainer = Color(0xFF005239)
val DarkOnPrimaryContainer = Color(0xFF8DF7C7)

