package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.PrescriptionEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.PharmacyViewModel

@Composable
fun PrescriptionsScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val prescriptions by viewModel.prescriptions.collectAsStateWithLifecycle()
    var showAddPrescriptionDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showAddPrescriptionDialog = true },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.PostAdd, contentDescription = "Add Prescription")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("নতুন প্রেসক্রিপশন সংরক্ষণ", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "রোগীদের প্রেসক্রিপশন ও ব্যবস্থাপত্র রেকর্ড",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "${prescriptions.size} টি রেকর্ড",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
            }

            if (prescriptions.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.Assignment,
                    title = "কোন প্রেসক্রিপশন রেকর্ড নেই",
                    description = "ডাক্তারের প্রেসক্রিপশন ও ওষুধের তালিকা সংরক্ষণ করতে নিচের বাটনে চাপুন।"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(prescriptions) { pres ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = "রোগী: ${pres.patientName}",
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        if (pres.patientPhone.isNotBlank()) {
                                            Text(
                                                text = "📱 ${pres.patientPhone}",
                                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                            )
                                        }
                                    }

                                    Surface(
                                        color = EmeraldContainer,
                                        shape = RoundedCornerShape(6.dp)
                                    ) {
                                        Text(
                                            text = formatShortDate(pres.timestamp),
                                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = EmeraldDark,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }
                                }

                                if (pres.doctorName.isNotBlank()) {
                                    Text(
                                        text = "👨‍⚕️ ডাক্তার: ${pres.doctorName}",
                                        style = MaterialTheme.typography.bodySmall.copy(
                                            color = TextSecondary,
                                            fontWeight = FontWeight.Medium
                                        ),
                                        modifier = Modifier.padding(top = 2.dp)
                                    )
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = DividerColor)

                                Text(
                                    text = "ঔষধের তালিকা ও নির্দেশনা:",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary, fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = pres.medicinesPrescribed,
                                    style = MaterialTheme.typography.bodyMedium,
                                    modifier = Modifier.padding(vertical = 2.dp)
                                )

                                if (pres.notes.isNotBlank()) {
                                    Text(
                                        text = "নোট: ${pres.notes}",
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                                        modifier = Modifier.padding(top = 4.dp)
                                    )
                                }

                                Spacer(modifier = Modifier.height(8.dp))

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End
                                ) {
                                    Button(
                                        onClick = {
                                            viewModel.posWalkInName = pres.patientName
                                            viewModel.posWalkInPhone = pres.patientPhone
                                            viewModel.navigateTo(AppScreen.POS_SALE)
                                        },
                                        shape = RoundedCornerShape(8.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                                    ) {
                                        Icon(imageVector = Icons.Default.ShoppingCartCheckout, contentDescription = null, modifier = Modifier.size(16.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("POS-এ বিক্রয় করুন", fontSize = 12.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddPrescriptionDialog) {
        AddPrescriptionDialog(
            onDismiss = { showAddPrescriptionDialog = false },
            onSave = { entity ->
                viewModel.savePrescription(entity)
                showAddPrescriptionDialog = false
            }
        )
    }
}

@Composable
private fun AddPrescriptionDialog(
    onDismiss: () -> Unit,
    onSave: (PrescriptionEntity) -> Unit
) {
    var patientName by remember { mutableStateOf("") }
    var patientPhone by remember { mutableStateOf("") }
    var doctorName by remember { mutableStateOf("") }
    var medicinesText by remember { mutableStateOf("") }
    var notes by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("নতুন প্রেসক্রিপশন এন্ট্রি", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                if (error != null) {
                    Text(error ?: "", color = RedAlert, style = MaterialTheme.typography.bodySmall)
                }

                OutlinedTextField(
                    value = patientName,
                    onValueChange = { patientName = it; error = null },
                    label = { Text("রোগীর নাম *") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = patientPhone,
                    onValueChange = { patientPhone = it },
                    label = { Text("রোগীর ফোন নম্বর") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = doctorName,
                    onValueChange = { doctorName = it },
                    label = { Text("ডাক্তারের নাম / হাসপাতাল") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                OutlinedTextField(
                    value = medicinesText,
                    onValueChange = { medicinesText = it; error = null },
                    label = { Text("ঔষধের তালিকা ও সেবনবিধি *") },
                    placeholder = { Text("১. Napa Extra (১+০+১)\n২. Seclo 20 (১+০+১ খাবারের আগে)") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(100.dp),
                    maxLines = 5
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("রোগীর বিশেষ নির্দেশনা / নোট") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                        Text("বাতিল")
                    }

                    Button(
                        onClick = {
                            if (patientName.isBlank() || medicinesText.isBlank()) {
                                error = "রোগীর নাম এবং ঔষধের তালিকা লিখুন।"
                                return@Button
                            }
                            val entity = PrescriptionEntity(
                                patientName = patientName.trim(),
                                patientPhone = patientPhone.trim(),
                                doctorName = doctorName.trim(),
                                medicinesPrescribed = medicinesText.trim(),
                                notes = notes.trim()
                            )
                            onSave(entity)
                        },
                        modifier = Modifier.weight(1.3f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("সংরক্ষণ করুন")
                    }
                }
            }
        }
    }
}
