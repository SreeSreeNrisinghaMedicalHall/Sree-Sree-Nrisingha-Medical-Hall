package com.example.ui.viewmodel

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableDoubleStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

enum class AppScreen {
    DASHBOARD,
    POS_SALE,
    MEDICINES,
    PURCHASE,
    CUSTOMERS,
    SUPPLIERS,
    ACCOUNTING,
    RETURNS,
    PRESCRIPTIONS,
    REPORTS,
    BACKUP_SETTINGS
}

class PharmacyViewModel(application: Application) : AndroidViewModel(application) {

    private val repository: PharmacyRepository

    init {
        val db = PharmacyDatabase.getDatabase(application)
        repository = PharmacyRepository(db.pharmacyDao())
    }

    // --- State Streams ---
    val medicines: StateFlow<List<MedicineEntity>> = repository.allMedicines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val lowStockMedicines: StateFlow<List<MedicineEntity>> = repository.lowStockMedicines
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val customers: StateFlow<List<CustomerEntity>> = repository.allCustomers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val suppliers: StateFlow<List<SupplierEntity>> = repository.allSuppliers
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val sales: StateFlow<List<SaleInvoiceEntity>> = repository.allSales
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val purchases: StateFlow<List<PurchaseInvoiceEntity>> = repository.allPurchases
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val cashTransactions: StateFlow<List<CashTransactionEntity>> = repository.allCashTransactions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val returnLogs: StateFlow<List<ReturnRecordEntity>> = repository.allReturns
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val prescriptions: StateFlow<List<PrescriptionEntity>> = repository.allPrescriptions
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val staffUsers: StateFlow<List<StaffUserEntity>> = repository.allStaff
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // --- UI Navigation ---
    var currentScreen by mutableStateOf(AppScreen.DASHBOARD)
    var currentUserRole by mutableStateOf("Owner (প্রদীপ চন্দ্র)")

    // --- Search & Filters ---
    var medicineSearchQuery by mutableStateOf("")
    var selectedCategoryFilter by mutableStateOf("All")
    var stockTabFilter by mutableStateOf("ALL") // ALL, LOW_STOCK, EXPIRING_SOON, EXPIRED

    var customerSearchQuery by mutableStateOf("")
    var supplierSearchQuery by mutableStateOf("")

    // --- POS Cart State ---
    val cart = mutableStateListOf<CartItem>()
    var posSelectedCustomer by mutableStateOf<CustomerEntity?>(null)
    var posWalkInName by mutableStateOf("")
    var posWalkInPhone by mutableStateOf("")
    var posDiscountAmount by mutableDoubleStateOf(0.0)
    var posPaymentMethod by mutableStateOf("Cash")
    var posPaidAmount by mutableDoubleStateOf(0.0)
    var posPrescriptionNote by mutableStateOf("")
    var lastCompletedInvoice by mutableStateOf<SaleInvoiceEntity?>(null)
    var lastCompletedCartItems by mutableStateOf<List<CartItem>>(emptyList())
    var showReceiptModal by mutableStateOf(false)

    // --- Backup & Cloud Status ---
    var lastBackupTimestamp by mutableStateOf(System.currentTimeMillis() - 3600000 * 2)
    var isCloudSyncing by mutableStateOf(false)
    var backupStatusMessage by mutableStateOf<String?>(null)

    // --- Navigation Helper ---
    fun navigateTo(screen: AppScreen) {
        currentScreen = screen
    }

    // --- POS Cart Methods ---
    fun addToCart(medicine: MedicineEntity) {
        val existingIndex = cart.indexOfFirst { it.medicineId == medicine.id }
        if (existingIndex >= 0) {
            val item = cart[existingIndex]
            if (item.quantity < medicine.stockQuantity) {
                cart[existingIndex] = item.copy(quantity = item.quantity + 1)
            }
        } else {
            if (medicine.stockQuantity > 0) {
                cart.add(
                    CartItem(
                        medicineId = medicine.id,
                        name = medicine.name,
                        genericName = medicine.genericName,
                        strength = medicine.strength,
                        unit = medicine.unit,
                        unitPrice = medicine.mrpPrice,
                        purchasePrice = medicine.purchasePrice,
                        quantity = 1,
                        stockAvailable = medicine.stockQuantity,
                        batchNumber = medicine.batchNumber,
                        expiryDate = medicine.expiryDate
                    )
                )
            }
        }
    }

    fun updateCartQuantity(medicineId: Long, newQuantity: Int) {
        val index = cart.indexOfFirst { it.medicineId == medicineId }
        if (index >= 0) {
            if (newQuantity <= 0) {
                cart.removeAt(index)
            } else {
                val item = cart[index]
                val safeQty = newQuantity.coerceAtMost(item.stockAvailable)
                cart[index] = item.copy(quantity = safeQty)
            }
        }
    }

    fun updateCartUnitPrice(medicineId: Long, newPrice: Double) {
        val index = cart.indexOfFirst { it.medicineId == medicineId }
        if (index >= 0) {
            cart[index] = cart[index].copy(unitPrice = newPrice)
        }
    }

    fun removeFromCart(medicineId: Long) {
        cart.removeAll { it.medicineId == medicineId }
    }

    fun clearCart() {
        cart.clear()
        posSelectedCustomer = null
        posWalkInName = ""
        posWalkInPhone = ""
        posDiscountAmount = 0.0
        posPaidAmount = 0.0
        posPrescriptionNote = ""
    }

    val cartSubtotal: Double
        get() = cart.sumOf { it.totalPrice }

    val cartGrandTotal: Double
        get() = (cartSubtotal - posDiscountAmount).coerceAtLeast(0.0)

    val cartTotalProfit: Double
        get() = (cart.sumOf { it.totalProfit } - posDiscountAmount).coerceAtLeast(0.0)

    fun checkoutPos(
        onSuccess: () -> Unit
    ) {
        if (cart.isEmpty()) return

        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val dateFormat = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault())
            val invoiceNo = "INV-${dateFormat.format(Date(now))}"

            val customerName = posSelectedCustomer?.name ?: if (posWalkInName.isNotBlank()) posWalkInName else "সাধারণ ক্রেতা (Walk-in)"
            val customerPhone = posSelectedCustomer?.phone ?: posWalkInPhone
            val customerId = posSelectedCustomer?.id

            val grandTotal = cartGrandTotal
            val paid = if (posPaymentMethod == "Due") 0.0 else if (posPaidAmount > 0) posPaidAmount.coerceAtMost(grandTotal) else grandTotal
            val due = (grandTotal - paid).coerceAtLeast(0.0)

            // Convert items to JSON
            val itemsJsonArray = JSONArray()
            for (item in cart) {
                val obj = JSONObject()
                obj.put("medicineId", item.medicineId)
                obj.put("name", item.name)
                obj.put("strength", item.strength)
                obj.put("unit", item.unit)
                obj.put("unitPrice", item.unitPrice)
                obj.put("purchasePrice", item.purchasePrice)
                obj.put("quantity", item.quantity)
                obj.put("total", item.totalPrice)
                obj.put("batch", item.batchNumber)
                itemsJsonArray.put(obj)
            }

            val saleInvoice = SaleInvoiceEntity(
                invoiceNumber = invoiceNo,
                customerName = customerName,
                customerPhone = customerPhone,
                customerId = customerId,
                subtotal = cartSubtotal,
                discount = posDiscountAmount,
                grandTotal = grandTotal,
                paidAmount = paid,
                dueAmount = due,
                paymentMethod = posPaymentMethod,
                timestamp = now,
                itemsJson = itemsJsonArray.toString(),
                totalProfit = cartTotalProfit,
                soldBy = "প্রদীপ চন্দ্র হাওলাদার",
                prescriptionNote = posPrescriptionNote
            )

            val currentCartCopy = cart.toList()
            repository.completeSale(saleInvoice, currentCartCopy)

            lastCompletedInvoice = saleInvoice
            lastCompletedCartItems = currentCartCopy
            showReceiptModal = true

            clearCart()
            onSuccess()
        }
    }

    // --- Medicine Management ---
    fun saveMedicine(medicine: MedicineEntity) {
        viewModelScope.launch {
            if (medicine.id == 0L) {
                repository.insertMedicine(medicine)
            } else {
                repository.updateMedicine(medicine)
            }
        }
    }

    fun deleteMedicine(medicine: MedicineEntity) {
        viewModelScope.launch {
            repository.deleteMedicine(medicine)
        }
    }

    // --- Customer Management ---
    fun saveCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            if (customer.id == 0L) {
                repository.insertCustomer(customer)
            } else {
                repository.updateCustomer(customer)
            }
        }
    }

    fun collectCustomerDue(customerId: Long, amount: Double, customerName: String, note: String) {
        viewModelScope.launch {
            repository.collectCustomerDue(customerId, amount, customerName, note)
        }
    }

    fun deleteCustomer(customer: CustomerEntity) {
        viewModelScope.launch {
            repository.deleteCustomer(customer)
        }
    }

    // --- Supplier Management ---
    fun saveSupplier(supplier: SupplierEntity) {
        viewModelScope.launch {
            if (supplier.id == 0L) {
                repository.insertSupplier(supplier)
            } else {
                repository.updateSupplier(supplier)
            }
        }
    }

    fun paySupplierDue(supplierId: Long, amount: Double, supplierName: String, note: String) {
        viewModelScope.launch {
            repository.paySupplierDue(supplierId, amount, supplierName, note)
        }
    }

    fun deleteSupplier(supplier: SupplierEntity) {
        viewModelScope.launch {
            repository.deleteSupplier(supplier)
        }
    }

    // --- Purchase Entry ---
    fun recordPurchase(
        supplier: SupplierEntity,
        items: List<CartItem>,
        paidAmount: Double,
        note: String
    ) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val dateFormat = SimpleDateFormat("yyyyMMdd-HHmm", Locale.getDefault())
            val invoiceNo = "PUR-${dateFormat.format(Date(now))}"
            val total = items.sumOf { it.purchasePrice * it.quantity }
            val due = (total - paidAmount).coerceAtLeast(0.0)

            val itemsJsonArray = JSONArray()
            for (item in items) {
                val obj = JSONObject()
                obj.put("medicineId", item.medicineId)
                obj.put("name", item.name)
                obj.put("quantity", item.quantity)
                obj.put("purchasePrice", item.purchasePrice)
                obj.put("batch", item.batchNumber)
                obj.put("expiry", item.expiryDate)
                itemsJsonArray.put(obj)
            }

            val purchase = PurchaseInvoiceEntity(
                invoiceNumber = invoiceNo,
                supplierId = supplier.id,
                supplierName = supplier.companyName,
                totalAmount = total,
                paidAmount = paidAmount,
                dueAmount = due,
                timestamp = now,
                itemsJson = itemsJsonArray.toString(),
                note = note
            )

            repository.completePurchase(purchase, items)
        }
    }

    // --- Accounting / Expense Management ---
    fun recordExpense(category: String, amount: Double, title: String, note: String) {
        viewModelScope.launch {
            repository.insertExpense(category, amount, title, note)
        }
    }

    fun recordIncome(category: String, amount: Double, title: String, note: String) {
        viewModelScope.launch {
            repository.insertIncome(category, amount, title, note)
        }
    }

    fun deleteTransaction(transaction: CashTransactionEntity) {
        viewModelScope.launch {
            repository.deleteCashTransaction(transaction)
        }
    }

    // --- Returns ---
    fun processReturn(
        medicine: MedicineEntity,
        quantity: Int,
        refundAmount: Double,
        isCustomerReturn: Boolean,
        reason: String
    ) {
        viewModelScope.launch {
            val returnRecord = ReturnRecordEntity(
                type = if (isCustomerReturn) "CUSTOMER_RETURN" else "SUPPLIER_RETURN",
                medicineId = medicine.id,
                medicineName = medicine.name,
                quantity = quantity,
                unitPrice = medicine.mrpPrice,
                totalAmount = refundAmount,
                partyName = if (isCustomerReturn) "কাস্টমার ফেরত" else medicine.company,
                reason = reason,
                timestamp = System.currentTimeMillis()
            )
            repository.processReturn(returnRecord)
        }
    }

    // --- Prescriptions ---
    fun savePrescription(prescription: PrescriptionEntity) {
        viewModelScope.launch {
            repository.insertPrescription(prescription)
        }
    }

    fun deletePrescription(prescription: PrescriptionEntity) {
        viewModelScope.launch {
            repository.deletePrescription(prescription)
        }
    }

    // --- Backup & Restore ---
    fun exportBackupJson(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val json = repository.generateBackupJson(
                medicines.value,
                customers.value,
                suppliers.value,
                sales.value,
                purchases.value,
                cashTransactions.value,
                staffUsers.value
            )
            onResult(json)
        }
    }

    fun restoreBackupJson(jsonString: String, onResult: (Boolean, String) -> Unit) {
        viewModelScope.launch {
            val success = repository.restoreBackupFromJson(jsonString)
            if (success) {
                lastBackupTimestamp = System.currentTimeMillis()
                val msg = "ডাটাবেজ সফলভাবে রিস্টোর হয়েছে!"
                backupStatusMessage = msg
                onResult(true, msg)
            } else {
                val msg = "ত্রুটি: ব্যাকআপ ফাইলটি পড়া যায়নি।"
                backupStatusMessage = msg
                onResult(false, msg)
            }
        }
    }

    fun triggerCloudSync() {
        viewModelScope.launch {
            isCloudSyncing = true
            kotlinx.coroutines.delay(1000)
            lastBackupTimestamp = System.currentTimeMillis()
            isCloudSyncing = false
            backupStatusMessage = "ক্লাউড সিঙ্ক সফল!"
        }
    }

    // --- Filter Helpers ---
    fun isMedicineExpiringSoon(expiryDateStr: String): Boolean {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = sdf.parse(expiryDateStr) ?: return false
            val cal = Calendar.getInstance()
            cal.add(Calendar.DAY_OF_YEAR, 90)
            val in90Days = cal.time
            date.after(Date()) && date.before(in90Days)
        } catch (e: Exception) {
            false
        }
    }

    fun isMedicineExpired(expiryDateStr: String): Boolean {
        return try {
            val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            val date = sdf.parse(expiryDateStr) ?: return false
            date.before(Date())
        } catch (e: Exception) {
            false
        }
    }
}
