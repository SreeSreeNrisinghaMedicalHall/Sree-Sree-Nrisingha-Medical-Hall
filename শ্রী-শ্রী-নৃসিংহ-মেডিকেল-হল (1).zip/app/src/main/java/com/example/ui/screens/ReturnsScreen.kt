package com.example.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.MedicineEntity
import com.example.data.ReturnRecordEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PharmacyViewModel

@Composable
fun ReturnsScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val returnLogs by viewModel.returnLogs.collectAsStateWithLifecycle()
    val medicines by viewModel.medicines.collectAsStateWithLifecycle()

    var showNewReturnDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewReturnDialog = true },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.AssignmentReturn, contentDescription = "New Return")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("ফেরত এন্ট্রি (Return)", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "বিক্রয় ও ক্রয় ফেরত লগ",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "মোট ফেরত: ${returnLogs.size}",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
            }

            if (returnLogs.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.AssignmentReturn,
                    title = "কোন ফেরত রেকর্ড নেই",
                    description = "কাস্টমার বা কোম্পানির নিকট ঔষধ ফেরত এন্ট্রি করতে নিচের বাটনে চাপুন।"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(returnLogs) { log ->
                        val isCustomerReturn = log.type == "CUSTOMER_RETURN"
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(12.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = log.medicineName,
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = if (isCustomerReturn) "কাস্টমার ফেরত (স্টকে যোগ হয়েছে)" else "কোম্পানি ফেরত (স্টক থেকে বাদ)",
                                            style = MaterialTheme.typography.labelSmall.copy(
                                                color = if (isCustomerReturn) GreenSuccess else AmberWarning,
                                                fontWeight = FontWeight.Bold
                                            )
                                        )
                                    }

                                    Text(
                                        text = formatCurrency(log.totalAmount),
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldDark
                                        )
                                    )
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = DividerColor)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "পরিমাণ: ${log.quantity} • কারণ: ${log.reason}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                    )
                                    Text(
                                        text = formatShortDate(log.timestamp),
                                        style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showNewReturnDialog) {
        NewReturnDialog(
            medicines = medicines,
            onDismiss = { showNewReturnDialog = false },
            onSave = { med, qty, amount, isCustomer, reason ->
                viewModel.processReturn(med, qty, amount, isCustomer, reason)
                showNewReturnDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewReturnDialog(
    medicines: List<MedicineEntity>,
    onDismiss: () -> Unit,
    onSave: (MedicineEntity, Int, Double, Boolean, String) -> Unit
) {
    var isCustomerReturn by remember { mutableStateOf(true) }
    var selectedMedicine by remember { mutableStateOf<MedicineEntity?>(medicines.firstOrNull()) }
    var medicineDropdownExpanded by remember { mutableStateOf(false) }
    var quantityText by remember { mutableStateOf("1") }
    var refundAmountText by remember { mutableStateOf(selectedMedicine?.mrpPrice?.toString() ?: "0.0") }
    var reason by remember { mutableStateOf("ভুল ঔষধ / মেয়াদোত্তীর্ণ") }
    var error by remember { mutableStateOf<String?>(null) }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            modifier = Modifier.fillMaxWidth(0.92f),
            shape = RoundedCornerShape(16.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "ফেরত এন্ট্রি (Return Processing)",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                // Return Type Selection
                SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                    SegmentedButton(
                        selected = isCustomerReturn,
                        onClick = { isCustomerReturn = true },
                        shape = SegmentedButtonDefaults.itemShape(index = 0, count = 2)
                    ) {
                        Text("কাস্টমার ফেরত (বিক্রয় ফেরত)")
                    }
                    SegmentedButton(
                        selected = !isCustomerReturn,
                        onClick = { isCustomerReturn = false },
                        shape = SegmentedButtonDefaults.itemShape(index = 1, count = 2)
                    ) {
                        Text("কোম্পানি ফেরত (ক্রয় ফেরত)")
                    }
                }

                if (error != null) {
                    Text(error ?: "", color = RedAlert, style = MaterialTheme.typography.bodySmall)
                }

                // Medicine Dropdown
                ExposedDropdownMenuBox(
                    expanded = medicineDropdownExpanded,
                    onExpandedChange = { medicineDropdownExpanded = !medicineDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedMedicine?.name ?: "ঔষধ নির্বাচন করুন",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("ঔষধের নাম *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = medicineDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = medicineDropdownExpanded,
                        onDismissRequest = { medicineDropdownExpanded = false }
                    ) {
                        medicines.forEach { med ->
                            DropdownMenuItem(
                                text = { Text("${med.name} (${med.strength})") },
                                onClick = {
                                    selectedMedicine = med
                                    refundAmountText = med.mrpPrice.toString()
                                    medicineDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = quantityText,
                        onValueChange = { quantityText = it },
                        label = { Text("ফেরত পরিমাণ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = refundAmountText,
                        onValueChange = { refundAmountText = it },
                        label = { Text("রিফান্ড মূল্য (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                OutlinedTextField(
                    value = reason,
                    onValueChange = { reason = it },
                    label = { Text("ফেরতের কারণ (e.g. অতিরিক্ত কেনা/মেয়াদ)") },
                    modifier = Modifier.fillMaxWidth(),
                    singleLine = true
                )

                Spacer(modifier = Modifier.height(4.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(onClick = onDismiss, modifier = Modifier.weight(1f), shape = RoundedCornerShape(10.dp)) {
                        Text("বাতিল")
                    }

                    Button(
                        onClick = {
                            val med = selectedMedicine
                            if (med == null) {
                                error = "ঔষধ নির্বাচন করুন।"
                                return@Button
                            }
                            val qty = quantityText.toIntOrNull() ?: 1
                            val amount = refundAmountText.toDoubleOrNull() ?: 0.0
                            onSave(med, qty, amount, isCustomerReturn, reason.trim())
                        },
                        modifier = Modifier.weight(1.3f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text("নিশ্চিত করুন")
                    }
                }
            }
        }
    }
}
