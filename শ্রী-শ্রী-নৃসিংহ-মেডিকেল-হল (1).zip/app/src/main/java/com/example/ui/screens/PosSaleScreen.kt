package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.MedicineEntity
import com.example.data.SampleData
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PharmacyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PosSaleScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val medicines by viewModel.medicines.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf("All") }
    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var customerDropdownExpanded by remember { mutableStateOf(false) }
    var showCheckoutSheet by remember { mutableStateOf(false) }

    // Filter medicines
    val filteredMedicines = remember(medicines, searchQuery, selectedCategory) {
        medicines.filter { med ->
            val matchQuery = searchQuery.isBlank() ||
                    med.name.contains(searchQuery, ignoreCase = true) ||
                    med.genericName.contains(searchQuery, ignoreCase = true) ||
                    med.company.contains(searchQuery, ignoreCase = true) ||
                    med.barcode.contains(searchQuery, ignoreCase = true)
            val matchCat = selectedCategory == "All" || med.category.equals(selectedCategory, ignoreCase = true)
            matchQuery && matchCat
        }
    }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        bottomBar = {
            // Cart Summary Sticky Footer
            if (viewModel.cart.isNotEmpty()) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 8.dp,
                    shadowElevation = 8.dp,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .navigationBarsPadding()
                            .padding(horizontal = 16.dp, vertical = 12.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${viewModel.cart.sumOf { it.quantity }} টি আইটেম কার্টে আছে",
                                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                                )
                                Text(
                                    text = formatCurrency(viewModel.cartSubtotal),
                                    style = MaterialTheme.typography.titleLarge.copy(
                                        fontWeight = FontWeight.Bold,
                                        color = EmeraldDark
                                    )
                                )
                            }

                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { viewModel.clearCart() },
                                    shape = RoundedCornerShape(10.dp)
                                ) {
                                    Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("মুছুন")
                                }

                                Button(
                                    onClick = { showCheckoutSheet = true },
                                    shape = RoundedCornerShape(10.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                                ) {
                                    Icon(imageVector = Icons.Default.ShoppingCartCheckout, contentDescription = null, modifier = Modifier.size(18.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("বিল তৈরি (Checkout)")
                                }
                            }
                        }
                    }
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar & Barcode Simulator
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                placeholder = { Text("ঔষধের নাম, জেনেরিক বা বারকোড খুঁজুন...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary)
                },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                        }
                    } else {
                        IconButton(onClick = {
                            // Demo quick barcode scan simulate
                            searchQuery = "894110010011"
                        }) {
                            Icon(imageVector = Icons.Default.QrCodeScanner, contentDescription = "Scan Barcode", tint = CyanAccent)
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Category Filter Chips
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                items(SampleData.medicineCategories) { cat ->
                    FilterChip(
                        selected = selectedCategory == cat,
                        onClick = { selectedCategory = cat },
                        label = { Text(cat, fontSize = 12.sp) },
                        leadingIcon = if (selectedCategory == cat) {
                            { Icon(imageVector = Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        } else null
                    )
                }
            }

            // Split View: Cart List on top (if not empty) and Medicine Catalog below
            LazyColumn(
                modifier = Modifier.weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                contentPadding = PaddingValues(bottom = 16.dp)
            ) {
                // Cart Items Section (if cart not empty)
                if (viewModel.cart.isNotEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(imageVector = Icons.Default.ShoppingCart, contentDescription = null, tint = EmeraldPrimary)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "নির্বাচিত ঔষধ (${viewModel.cart.size} প্রকার)",
                                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                        )
                                    }
                                    Text(
                                        text = formatCurrency(viewModel.cartSubtotal),
                                        style = MaterialTheme.typography.titleSmall.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldPrimary
                                        )
                                    )
                                }

                                Divider(color = DividerColor, modifier = Modifier.padding(vertical = 8.dp))

                                // Cart Item Rows
                                viewModel.cart.forEach { cartItem ->
                                    CartItemRow(
                                        item = cartItem,
                                        onIncrease = { viewModel.updateCartQuantity(cartItem.medicineId, cartItem.quantity + 1) },
                                        onDecrease = { viewModel.updateCartQuantity(cartItem.medicineId, cartItem.quantity - 1) },
                                        onRemove = { viewModel.removeFromCart(cartItem.medicineId) }
                                    )
                                    Spacer(modifier = Modifier.height(6.dp))
                                }
                            }
                        }
                    }
                }

                // Section Header for Medicine Search Results
                item {
                    Text(
                        text = "ঔষধ তালিকা (${filteredMedicines.size}) - ট্যাপ করে যোগ করুন",
                        style = MaterialTheme.typography.titleSmall.copy(
                            fontWeight = FontWeight.Bold,
                            color = TextSecondary
                        ),
                        modifier = Modifier.padding(top = 4.dp)
                    )
                }

                if (filteredMedicines.isEmpty()) {
                    item {
                        EmptyStateCard(
                            icon = Icons.Default.SearchOff,
                            title = "কোন ঔষধ পাওয়া যায়নি",
                            description = "অন্য নাম দিয়ে খুঁজুন অথবা নতুন ঔষধ যোগ করুন।"
                        )
                    }
                } else {
                    items(filteredMedicines, key = { it.id }) { med ->
                        MedicinePosCard(
                            medicine = med,
                            onAddToCart = { viewModel.addToCart(med) }
                        )
                    }
                }
            }
        }
    }

    // Checkout BottomSheet Modal
    if (showCheckoutSheet) {
        ModalBottomSheet(
            onDismissRequest = { showCheckoutSheet = false },
            containerColor = MaterialTheme.colorScheme.surface
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 12.dp)
                    .navigationBarsPadding(),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = "ক্যাশ মেমো ও পেমেন্ট নিষ্পত্তি",
                    style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = EmeraldDark)
                )

                // Customer Selection
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    ExposedDropdownMenuBox(
                        expanded = customerDropdownExpanded,
                        onExpandedChange = { customerDropdownExpanded = !customerDropdownExpanded },
                        modifier = Modifier.weight(1f)
                    ) {
                        OutlinedTextField(
                            value = viewModel.posSelectedCustomer?.name ?: if (viewModel.posWalkInName.isNotBlank()) viewModel.posWalkInName else "সাধারণ ক্রেতা (Walk-in)",
                            onValueChange = { viewModel.posWalkInName = it },
                            label = { Text("কাস্টমার") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = customerDropdownExpanded) },
                            modifier = Modifier
                                .menuAnchor()
                                .fillMaxWidth()
                        )
                        ExposedDropdownMenu(
                            expanded = customerDropdownExpanded,
                            onDismissRequest = { customerDropdownExpanded = false }
                        ) {
                            DropdownMenuItem(
                                text = { Text("সাধারণ ক্রেতা (Walk-in)") },
                                onClick = {
                                    viewModel.posSelectedCustomer = null
                                    viewModel.posWalkInName = ""
                                    customerDropdownExpanded = false
                                }
                            )
                            customers.forEach { cust ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(cust.name, fontWeight = FontWeight.Bold)
                                            Text(
                                                "${cust.phone} • বাকি: ${formatCurrency(cust.currentDue)}",
                                                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                            )
                                        }
                                    },
                                    onClick = {
                                        viewModel.posSelectedCustomer = cust
                                        viewModel.posWalkInName = cust.name
                                        viewModel.posWalkInPhone = cust.phone
                                        customerDropdownExpanded = false
                                    }
                                )
                            }
                        }
                    }

                    IconButton(
                        onClick = { showAddCustomerDialog = true },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(EmeraldContainer)
                    ) {
                        Icon(imageVector = Icons.Default.PersonAdd, contentDescription = "Add Customer", tint = EmeraldPrimary)
                    }
                }

                // Discount Input
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    var discountText by remember { mutableStateOf(if (viewModel.posDiscountAmount > 0) viewModel.posDiscountAmount.toString() else "") }

                    OutlinedTextField(
                        value = discountText,
                        onValueChange = {
                            discountText = it
                            viewModel.posDiscountAmount = it.toDoubleOrNull() ?: 0.0
                        },
                        label = { Text("বিশেষ ছাড় / Discount (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )

                    // Payment Method Chips
                    val paymentMethods = listOf("Cash", "bKash / Nagad", "Card", "Due")
                    Column(modifier = Modifier.weight(1.3f)) {
                        Text("পরিশোধের মাধ্যম:", style = MaterialTheme.typography.labelSmall)
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            paymentMethods.take(2).forEach { method ->
                                FilterChip(
                                    selected = viewModel.posPaymentMethod == method,
                                    onClick = { viewModel.posPaymentMethod = method },
                                    label = { Text(method, fontSize = 11.sp) }
                                )
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                            paymentMethods.drop(2).forEach { method ->
                                FilterChip(
                                    selected = viewModel.posPaymentMethod == method,
                                    onClick = { viewModel.posPaymentMethod = method },
                                    label = { Text(method, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }

                // Bill Breakdown Card
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = EmeraldContainer.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("সাবটোটাল:", style = MaterialTheme.typography.bodyMedium)
                            Text(formatCurrency(viewModel.cartSubtotal), style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
                        }
                        if (viewModel.posDiscountAmount > 0) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("ছাড়:", style = MaterialTheme.typography.bodyMedium.copy(color = AmberWarning))
                                Text("- " + formatCurrency(viewModel.posDiscountAmount), style = MaterialTheme.typography.bodyMedium.copy(color = AmberWarning, fontWeight = FontWeight.Bold))
                            }
                        }
                        HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text("সর্বমোট প্রদেয় বিল:", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                            Text(formatCurrency(viewModel.cartGrandTotal), style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldDark))
                        }
                    }
                }

                // Complete Sale Button
                Button(
                    onClick = {
                        viewModel.checkoutPos {
                            showCheckoutSheet = false
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Icon(imageVector = Icons.Default.CheckCircle, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("বিক্রয় সম্পন্ন ও মেমো প্রিন্ট", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                }
            }
        }
    }

    if (showAddCustomerDialog) {
        AddCustomerDialog(
            onDismiss = { showAddCustomerDialog = false },
            onSave = { newCust ->
                viewModel.saveCustomer(newCust)
                viewModel.posSelectedCustomer = newCust
                viewModel.posWalkInName = newCust.name
                viewModel.posWalkInPhone = newCust.phone
            }
        )
    }
}

@Composable
private fun CartItemRow(
    item: com.example.data.CartItem,
    onIncrease: () -> Unit,
    onDecrease: () -> Unit,
    onRemove: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(SlateBackground)
            .padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Column(modifier = Modifier.weight(1.5f)) {
            Text(
                text = item.name,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
            )
            Text(
                text = "${formatCurrency(item.unitPrice)} / ${item.unit} (${item.strength})",
                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
            )
        }

        // Stepper Quantity Controller
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            FilledTonalIconButton(
                onClick = onDecrease,
                modifier = Modifier.size(28.dp),
                shape = CircleShape
            ) {
                Icon(imageVector = Icons.Default.Remove, contentDescription = "Decrease", modifier = Modifier.size(14.dp))
            }

            Text(
                text = item.quantity.toString(),
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            FilledTonalIconButton(
                onClick = onIncrease,
                modifier = Modifier.size(28.dp),
                shape = CircleShape
            ) {
                Icon(imageVector = Icons.Default.Add, contentDescription = "Increase", modifier = Modifier.size(14.dp))
            }
        }

        Spacer(modifier = Modifier.width(8.dp))

        Text(
            text = formatCurrency(item.totalPrice),
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldDark)
        )

        IconButton(
            onClick = onRemove,
            modifier = Modifier.size(28.dp)
        ) {
            Icon(imageVector = Icons.Default.Close, contentDescription = "Remove", tint = RedAlert, modifier = Modifier.size(16.dp))
        }
    }
}

@Composable
private fun MedicinePosCard(
    medicine: MedicineEntity,
    onAddToCart: () -> Unit
) {
    val isOutOfStock = medicine.stockQuantity <= 0

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .then(if (!isOutOfStock) Modifier.clickable { onAddToCart() } else Modifier),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = SurfaceCard),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1.5f)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = medicine.name,
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = CyanAccentContainer,
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = medicine.category,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp),
                            style = MaterialTheme.typography.labelSmall.copy(
                                fontSize = 10.sp,
                                color = CyanAccent
                            )
                        )
                    }
                }

                if (medicine.genericName.isNotBlank()) {
                    Text(
                        text = medicine.genericName,
                        style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                        maxLines = 1
                    )
                }

                Text(
                    text = "${medicine.company} • ${medicine.strength}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary),
                    fontSize = 11.sp,
                    maxLines = 1
                )

                Row(
                    modifier = Modifier.padding(top = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StockBadge(quantity = medicine.stockQuantity, minThreshold = medicine.minStockAlert)
                    if (medicine.shelfLocation.isNotBlank()) {
                        Text(
                            text = "📍 ${medicine.shelfLocation}",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary, fontSize = 10.sp)
                        )
                    }
                }
            }

            Column(
                horizontalAlignment = Alignment.End,
                verticalArrangement = Arrangement.Center
            ) {
                Text(
                    text = formatCurrency(medicine.mrpPrice),
                    style = MaterialTheme.typography.titleMedium.copy(
                        fontWeight = FontWeight.Bold,
                        color = EmeraldDark
                    )
                )
                Text(
                    text = "প্রতি ${medicine.unit}",
                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                )

                Spacer(modifier = Modifier.height(4.dp))

                FilledTonalButton(
                    onClick = onAddToCart,
                    enabled = !isOutOfStock,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = EmeraldContainer,
                        contentColor = EmeraldDark
                    )
                ) {
                    Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(if (isOutOfStock) "স্টক নাই" else "যোগ", fontSize = 12.sp)
                }
            }
        }
    }
}
