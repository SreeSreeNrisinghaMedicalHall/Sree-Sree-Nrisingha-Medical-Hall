package com.example.ui.components

import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.CartItem
import com.example.data.SaleInvoiceEntity
import com.example.ui.theme.*
import org.json.JSONArray

@Composable
fun ReceiptDialog(
    invoice: SaleInvoiceEntity,
    cartItems: List<CartItem>,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    // Parse items if cartItems is empty
    val itemsList = if (cartItems.isNotEmpty()) {
        cartItems
    } else {
        try {
            val arr = JSONArray(invoice.itemsJson)
            val list = mutableListOf<CartItem>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    CartItem(
                        medicineId = obj.optLong("medicineId", 0L),
                        name = obj.optString("name", "Medicine"),
                        genericName = "",
                        strength = obj.optString("strength", ""),
                        unit = obj.optString("unit", "Pcs"),
                        unitPrice = obj.optDouble("unitPrice", 0.0),
                        purchasePrice = obj.optDouble("purchasePrice", 0.0),
                        quantity = obj.optInt("quantity", 1),
                        stockAvailable = 0,
                        batchNumber = obj.optString("batch", "")
                    )
                )
            }
            list
        } catch (e: Exception) {
            emptyList()
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .fillMaxHeight(0.88f)
                .clip(RoundedCornerShape(20.dp)),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 8.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            ) {
                // Modal Top Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.ReceiptLong,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "বিক্রয় রশিদ / Cash Memo",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                Divider(color = DividerColor, modifier = Modifier.padding(vertical = 8.dp))

                // Scrollable Thermal Paper Slip
                Box(
                    modifier = Modifier
                        .weight(1f)
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFFFFFDF8))
                        .border(1.dp, Color(0xFFE2DDD5), RoundedCornerShape(8.dp))
                        .padding(16.dp)
                        .verticalScroll(rememberScrollState())
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        // Store Branding
                        Text(
                            text = "শ্রী শ্রী নৃসিংহ মেডিকেল হল",
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = EmeraldDark,
                                fontSize = 18.sp
                            ),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "ফার্মেসি ও সার্জিক্যাল সামগ্রী বিক্রেতা",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "প্রোপ্রাইটর: প্রদীপ চন্দ্র হাওলাদার",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "মোবাইল: ০১৭৩৯০৯৭৩৯০",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "সোনাখালী, আমতলী, বরগুনা",
                            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary),
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "------------------------------------------------",
                            color = Color.Gray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )

                        // Invoice Details
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Memo: ${invoice.invoiceNumber}",
                                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = formatShortDate(invoice.timestamp),
                                style = MaterialTheme.typography.labelMedium
                            )
                        }

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Customer: ${invoice.customerName}",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Medium)
                            )
                            if (invoice.customerPhone.isNotBlank()) {
                                Text(
                                    text = invoice.customerPhone,
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        if (invoice.soldBy.isNotBlank()) {
                            Row(modifier = Modifier.fillMaxWidth()) {
                                Text(
                                    text = "Served By: ${invoice.soldBy}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "------------------------------------------------",
                            color = Color.Gray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )

                        // Table Header
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "Item / Description",
                                modifier = Modifier.weight(2.2f),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = "Qty",
                                modifier = Modifier.weight(0.7f),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.Center
                                )
                            )
                            Text(
                                text = "Price",
                                modifier = Modifier.weight(0.9f),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.End
                                )
                            )
                            Text(
                                text = "Total",
                                modifier = Modifier.weight(1.1f),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    textAlign = TextAlign.End
                                )
                            )
                        }

                        Divider(color = Color.LightGray, thickness = 0.8.dp)

                        // Items list
                        for (item in itemsList) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 4.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(2.2f)) {
                                    Text(
                                        text = item.name,
                                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold),
                                        maxLines = 1
                                    )
                                    if (item.strength.isNotBlank()) {
                                        Text(
                                            text = item.strength,
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary),
                                            fontSize = 10.sp
                                        )
                                    }
                                }
                                Text(
                                    text = "${item.quantity} ${item.unit}",
                                    modifier = Modifier.weight(0.7f),
                                    style = MaterialTheme.typography.bodySmall.copy(textAlign = TextAlign.Center)
                                )
                                Text(
                                    text = String.format("%.2f", item.unitPrice),
                                    modifier = Modifier.weight(0.9f),
                                    style = MaterialTheme.typography.bodySmall.copy(textAlign = TextAlign.End)
                                )
                                Text(
                                    text = formatCurrency(item.totalPrice),
                                    modifier = Modifier.weight(1.1f),
                                    style = MaterialTheme.typography.bodySmall.copy(
                                        fontWeight = FontWeight.Medium,
                                        textAlign = TextAlign.End
                                    )
                                )
                            }
                        }

                        Text(
                            text = "------------------------------------------------",
                            color = Color.Gray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )

                        // Subtotal & Calculations
                        ReceiptRow(label = "Subtotal / মোট:", value = formatCurrency(invoice.subtotal))
                        if (invoice.discount > 0) {
                            ReceiptRow(
                                label = "Discount / ছাড়:",
                                value = "- " + formatCurrency(invoice.discount),
                                valueColor = AmberWarning
                            )
                        }

                        Divider(color = Color.LightGray, thickness = 1.dp, modifier = Modifier.padding(vertical = 4.dp))

                        ReceiptRow(
                            label = "Grand Total / সর্বমোট:",
                            value = formatCurrency(invoice.grandTotal),
                            isBold = true,
                            fontSize = 15
                        )
                        ReceiptRow(
                            label = "Paid / পরিশোধ (${invoice.paymentMethod}):",
                            value = formatCurrency(invoice.paidAmount),
                            valueColor = GreenSuccess,
                            isBold = true
                        )

                        if (invoice.dueAmount > 0) {
                            ReceiptRow(
                                label = "Due / বাকি:",
                                value = formatCurrency(invoice.dueAmount),
                                valueColor = RedAlert,
                                isBold = true
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "------------------------------------------------",
                            color = Color.Gray,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp
                        )

                        Text(
                            text = "ঔষধ কেনার পর অনুগ্রহ করে মেয়াদ ও সিল দেখে নিন।",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = TextSecondary,
                                fontSize = 10.sp
                            ),
                            textAlign = TextAlign.Center
                        )
                        Text(
                            text = "সুস্থ থাকুন, সুস্থ রাখুন। ধন্যবাদ!",
                            style = MaterialTheme.typography.bodySmall.copy(
                                fontWeight = FontWeight.Bold,
                                color = EmeraldDark
                            ),
                            textAlign = TextAlign.Center,
                            modifier = Modifier.padding(top = 4.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Action Buttons (Share / SMS / Close)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("বন্ধ করুন")
                    }

                    Button(
                        onClick = {
                            val shareBody = buildString {
                                appendLine("শ্রী শ্রী নৃসিংহ মেডিকেল হল")
                                appendLine("প্রোপ্রাইটর: প্রদীপ চন্দ্র হাওলাদার")
                                appendLine("মোবাইল: ০১৭৩৯০৯৭৩৯০")
                                appendLine("সোনাখালী, আমতলী, বরগুনা")
                                appendLine("-----------------------------")
                                appendLine("ইনভয়েস: ${invoice.invoiceNumber}")
                                appendLine("ক্রেতা: ${invoice.customerName}")
                                appendLine("তারিখ: ${formatDate(invoice.timestamp)}")
                                appendLine("-----------------------------")
                                for (item in itemsList) {
                                    appendLine("${item.name} (${item.quantity} ${item.unit}) = ${formatCurrency(item.totalPrice)}")
                                }
                                appendLine("-----------------------------")
                                appendLine("সর্বমোট: ${formatCurrency(invoice.grandTotal)}")
                                appendLine("পরিশোধ: ${formatCurrency(invoice.paidAmount)}")
                                if (invoice.dueAmount > 0) {
                                    appendLine("বাকি: ${formatCurrency(invoice.dueAmount)}")
                                }
                                appendLine("ধন্যবাদ!")
                            }

                            val intent = Intent(Intent.ACTION_SEND).apply {
                                type = "text/plain"
                                putExtra(Intent.EXTRA_SUBJECT, "Medical Memo: ${invoice.invoiceNumber}")
                                putExtra(Intent.EXTRA_TEXT, shareBody)
                            }
                            context.startActivity(Intent.createChooser(intent, "শেয়ার করুন রসিদ"))
                        },
                        modifier = Modifier.weight(1.3f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Icon(imageVector = Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("মেমো শেয়ার")
                    }
                }
            }
        }
    }
}

@Composable
private fun ReceiptRow(
    label: String,
    value: String,
    valueColor: Color = TextPrimary,
    isBold: Boolean = false,
    fontSize: Int = 13
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 2.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
                color = TextSecondary,
                fontSize = fontSize.sp
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodySmall.copy(
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.SemiBold,
                color = valueColor,
                fontSize = fontSize.sp
            )
        )
    }
}
