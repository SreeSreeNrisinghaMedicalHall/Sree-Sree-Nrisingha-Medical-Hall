package com.example.ui.screens

import android.content.Intent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PharmacyViewModel
import java.util.Calendar

@Composable
fun ReportsScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val medicines by viewModel.medicines.collectAsStateWithLifecycle()
    val cashTransactions by viewModel.cashTransactions.collectAsStateWithLifecycle()

    var selectedPeriod by remember { mutableStateOf("TODAY") } // TODAY, WEEK, MONTH, ALL

    // Time calculations
    val now = System.currentTimeMillis()
    val cal = Calendar.getInstance()

    val periodStartTimestamp = remember(selectedPeriod) {
        cal.timeInMillis = now
        cal.set(Calendar.HOUR_OF_DAY, 0)
        cal.set(Calendar.MINUTE, 0)
        cal.set(Calendar.SECOND, 0)
        cal.set(Calendar.MILLISECOND, 0)

        when (selectedPeriod) {
            "TODAY" -> cal.timeInMillis
            "WEEK" -> {
                cal.add(Calendar.DAY_OF_YEAR, -7)
                cal.timeInMillis
            }
            "MONTH" -> {
                cal.add(Calendar.DAY_OF_YEAR, -30)
                cal.timeInMillis
            }
            else -> 0L
        }
    }

    val periodSales = remember(sales, periodStartTimestamp) {
        sales.filter { it.timestamp >= periodStartTimestamp }
    }
    val periodPurchases = remember(purchases, periodStartTimestamp) {
        purchases.filter { it.timestamp >= periodStartTimestamp }
    }
    val periodExpenses = remember(cashTransactions, periodStartTimestamp) {
        cashTransactions.filter { it.timestamp >= periodStartTimestamp && (it.type.startsWith("EXPENSE") || it.type == "OTHER_EXPENSE") }
    }

    val totalSalesAmount = periodSales.sumOf { it.grandTotal }
    val totalGrossProfit = periodSales.sumOf { it.totalProfit }
    val totalPurchaseAmount = periodPurchases.sumOf { it.totalAmount }
    val totalExpenseAmount = periodExpenses.sumOf { it.amount }
    val netEstimatedProfit = totalGrossProfit - totalExpenseAmount

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 28.dp)
    ) {
        // Period Tabs
        item {
            SingleChoiceSegmentedButtonRow(modifier = Modifier.fillMaxWidth()) {
                SegmentedButton(
                    selected = selectedPeriod == "TODAY",
                    onClick = { selectedPeriod = "TODAY" },
                    shape = SegmentedButtonDefaults.itemShape(index = 0, count = 4)
                ) {
                    Text("আজ")
                }
                SegmentedButton(
                    selected = selectedPeriod == "WEEK",
                    onClick = { selectedPeriod = "WEEK" },
                    shape = SegmentedButtonDefaults.itemShape(index = 1, count = 4)
                ) {
                    Text("৭ দিন")
                }
                SegmentedButton(
                    selected = selectedPeriod == "MONTH",
                    onClick = { selectedPeriod = "MONTH" },
                    shape = SegmentedButtonDefaults.itemShape(index = 2, count = 4)
                ) {
                    Text("৩০ দিন")
                }
                SegmentedButton(
                    selected = selectedPeriod == "ALL",
                    onClick = { selectedPeriod = "ALL" },
                    shape = SegmentedButtonDefaults.itemShape(index = 3, count = 4)
                ) {
                    Text("সব সময়")
                }
            }
        }

        // Financial Summary Overview Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Text(
                        text = "আর্থিক বিবরণী ও লাভ-ক্ষতি রিপোর্ট",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldDark)
                    )

                    HorizontalDivider(modifier = Modifier.padding(vertical = 10.dp), color = DividerColor)

                    ReportStatRow("মোট বিক্রয় (Total Sales):", formatCurrency(totalSalesAmount), TextPrimary, true)
                    ReportStatRow("মোট ক্রয় চালান (Total Purchases):", formatCurrency(totalPurchaseAmount), TextSecondary)
                    ReportStatRow("গ্রস লাভ (Gross Profit on Sales):", formatCurrency(totalGrossProfit), GreenSuccess, true)
                    ReportStatRow("দোকান পরিচালন ব্যয় (Shop Expenses):", "- " + formatCurrency(totalExpenseAmount), RedAlert)

                    HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = DividerColor)

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "নেট আনুমানিক লাভ (Net Profit):",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            text = formatCurrency(netEstimatedProfit),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = if (netEstimatedProfit >= 0) GreenSuccess else RedAlert
                            )
                        )
                    }
                }
            }
        }

        // Share / Export Report Button
        item {
            Button(
                onClick = {
                    val reportText = buildString {
                        appendLine("📊 শ্রী শ্রী নৃসিংহ মেডিকেল হল - আর্থিক রিপোর্ট")
                        appendLine("প্রোপ্রাইটর: প্রদীপ চন্দ্র হাওলাদার (০১৭৩৯০৯৭৩৯০)")
                        appendLine("সোনাখালী, আমতলী, বরগুনা")
                        appendLine("----------------------------------")
                        appendLine("সময়কাল: $selectedPeriod")
                        appendLine("মোট বিক্রয়: ${formatCurrency(totalSalesAmount)}")
                        appendLine("মোট ক্রয়: ${formatCurrency(totalPurchaseAmount)}")
                        appendLine("গ্রস লাভ: ${formatCurrency(totalGrossProfit)}")
                        appendLine("দোকান খরচ: ${formatCurrency(totalExpenseAmount)}")
                        appendLine("নেট লাভ: ${formatCurrency(netEstimatedProfit)}")
                        appendLine("ইনভেন্টরি বর্তমান স্টক সংখ্যা: ${medicines.size} টি")
                    }

                    val sendIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_SUBJECT, "ফার্মেসি রিপোর্ট - শ্রী শ্রী নৃসিংহ মেডিকেল হল")
                        putExtra(Intent.EXTRA_TEXT, reportText)
                    }
                    context.startActivity(Intent.createChooser(sendIntent, "রিপোর্ট শেয়ার করুন"))
                },
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Icon(imageVector = Icons.Default.Share, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text("রিপোর্ট শেয়ার / ব্যাকআপ এক্সপোর্ট", fontWeight = FontWeight.Bold)
            }
        }

        // Sales Invoices in Period
        item {
            Text(
                text = "বিক্রয় মেমো তালিকা (${periodSales.size} টি)",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        if (periodSales.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.Default.Assessment,
                    title = "এই সময়কালে কোন বিক্রয় নেই",
                    description = "অন্য সময়কাল নির্বাচন করুন।"
                )
            }
        } else {
            items(periodSales) { sale ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "${sale.invoiceNumber} • ${sale.customerName}",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                text = formatDate(sale.timestamp),
                                style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = formatCurrency(sale.grandTotal),
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = EmeraldDark
                                )
                            )
                            Text(
                                text = "লাভ: ${formatCurrency(sale.totalProfit)}",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = GreenSuccess,
                                    fontWeight = FontWeight.SemiBold
                                )
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ReportStatRow(
    label: String,
    value: String,
    valueColor: Color = TextPrimary,
    isBold: Boolean = false
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = if (isBold) FontWeight.SemiBold else FontWeight.Normal,
                color = TextSecondary
            )
        )
        Text(
            text = value,
            style = MaterialTheme.typography.bodyMedium.copy(
                fontWeight = if (isBold) FontWeight.Bold else FontWeight.Medium,
                color = valueColor
            )
        )
    }
}
