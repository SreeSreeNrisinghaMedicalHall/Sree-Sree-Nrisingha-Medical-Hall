package com.example.ui.components

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Medication
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.data.MedicineEntity
import com.example.data.SampleData
import com.example.ui.theme.EmeraldPrimary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditMedicineDialog(
    initialMedicine: MedicineEntity? = null,
    onDismiss: () -> Unit,
    onSave: (MedicineEntity) -> Unit
) {
    var name by remember { mutableStateOf(initialMedicine?.name ?: "") }
    var genericName by remember { mutableStateOf(initialMedicine?.genericName ?: "") }
    var company by remember { mutableStateOf(initialMedicine?.company ?: "") }
    var category by remember { mutableStateOf(initialMedicine?.category ?: "Tablet") }
    var strength by remember { mutableStateOf(initialMedicine?.strength ?: "") }
    var unit by remember { mutableStateOf(initialMedicine?.unit ?: "Pcs") }
    var purchasePriceText by remember { mutableStateOf(initialMedicine?.purchasePrice?.toString() ?: "") }
    var mrpPriceText by remember { mutableStateOf(initialMedicine?.mrpPrice?.toString() ?: "") }
    var stockQuantityText by remember { mutableStateOf(initialMedicine?.stockQuantity?.toString() ?: "50") }
    var minStockAlertText by remember { mutableStateOf(initialMedicine?.minStockAlert?.toString() ?: "20") }
    var batchNumber by remember { mutableStateOf(initialMedicine?.batchNumber ?: "B-2026") }
    var expiryDate by remember { mutableStateOf(initialMedicine?.expiryDate ?: "2027-12-31") }
    var barcode by remember { mutableStateOf(initialMedicine?.barcode ?: "") }
    var shelfLocation by remember { mutableStateOf(initialMedicine?.shelfLocation ?: "Rack A-1") }

    var categoryDropdownExpanded by remember { mutableStateOf(false) }
    var validationError by remember { mutableStateOf<String?>(null) }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Surface(
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .fillMaxHeight(0.92f),
            shape = RoundedCornerShape(20.dp),
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 6.dp
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(20.dp)
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Medication,
                            contentDescription = null,
                            tint = EmeraldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (initialMedicine == null) "নতুন ঔষধ যোগ করুন" else "ঔষধ তথ্য সংশোধন",
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                // Scrollable Form Fields
                Column(
                    modifier = Modifier
                        .weight(1f)
                        .verticalScroll(rememberScrollState()),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    if (validationError != null) {
                        Surface(
                            color = MaterialTheme.colorScheme.errorContainer,
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = validationError ?: "",
                                color = MaterialTheme.colorScheme.onErrorContainer,
                                modifier = Modifier.padding(10.dp),
                                style = MaterialTheme.typography.bodySmall
                            )
                        }
                    }

                    // Medicine Name
                    OutlinedTextField(
                        value = name,
                        onValueChange = { name = it; validationError = null },
                        label = { Text("ঔষধের বাণিজ্যিক নাম (e.g. Napa Extra) *") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Generic Name
                    OutlinedTextField(
                        value = genericName,
                        onValueChange = { genericName = it },
                        label = { Text("জেনেরিক নাম (e.g. Paracetamol + Caffeine)") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )

                    // Company & Category
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = company,
                            onValueChange = { company = it },
                            label = { Text("কোম্পানি / প্রস্তুতকারক") },
                            modifier = Modifier.weight(1.3f),
                            singleLine = true
                        )

                        // Category Dropdown
                        ExposedDropdownMenuBox(
                            expanded = categoryDropdownExpanded,
                            onExpandedChange = { categoryDropdownExpanded = !categoryDropdownExpanded },
                            modifier = Modifier.weight(1f)
                        ) {
                            OutlinedTextField(
                                value = category,
                                onValueChange = {},
                                readOnly = true,
                                label = { Text("ধরন") },
                                trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = categoryDropdownExpanded) },
                                modifier = Modifier.menuAnchor()
                            )
                            ExposedDropdownMenu(
                                expanded = categoryDropdownExpanded,
                                onDismissRequest = { categoryDropdownExpanded = false }
                            ) {
                                SampleData.medicineCategories.filter { it != "All" }.forEach { cat ->
                                    DropdownMenuItem(
                                        text = { Text(cat) },
                                        onClick = {
                                            category = cat
                                            categoryDropdownExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    // Strength & Unit
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = strength,
                            onValueChange = { strength = it },
                            label = { Text("পাওয়ার / Strength (e.g. 500mg)") },
                            modifier = Modifier.weight(1.2f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = unit,
                            onValueChange = { unit = it },
                            label = { Text("একক / Unit (Pcs/Strip/Box)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    // Purchase Price & MRP Price
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = purchasePriceText,
                            onValueChange = { purchasePriceText = it },
                            label = { Text("ক্রয়মূল্য (৳) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = mrpPriceText,
                            onValueChange = { mrpPriceText = it },
                            label = { Text("বিক্রয়মূল্য MRP (৳) *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    // Stock Quantity & Alert Limit
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = stockQuantityText,
                            onValueChange = { stockQuantityText = it },
                            label = { Text("বর্তমান স্টক *") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = minStockAlertText,
                            onValueChange = { minStockAlertText = it },
                            label = { Text("কম স্টক সংকেত") },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }

                    // Batch & Expiry
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = batchNumber,
                            onValueChange = { batchNumber = it },
                            label = { Text("ব্যাচ নং") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = expiryDate,
                            onValueChange = { expiryDate = it },
                            label = { Text("মেয়াদ (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1.2f),
                            singleLine = true
                        )
                    }

                    // Barcode & Shelf Location
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = barcode,
                            onValueChange = { barcode = it },
                            label = { Text("বারকোড নং (ঐচ্ছিক)") },
                            modifier = Modifier.weight(1.2f),
                            singleLine = true
                        )
                        OutlinedTextField(
                            value = shelfLocation,
                            onValueChange = { shelfLocation = it },
                            label = { Text("র্যাক / তাক (e.g. Rack A-1)") },
                            modifier = Modifier.weight(1f),
                            singleLine = true
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Actions
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Text("বাতিল")
                    }

                    Button(
                        onClick = {
                            if (name.isBlank()) {
                                validationError = "ঔষধের নাম প্রদান করুন।"
                                return@Button
                            }
                            val pPrice = purchasePriceText.toDoubleOrNull() ?: 0.0
                            val sPrice = mrpPriceText.toDoubleOrNull() ?: 0.0
                            if (sPrice <= 0) {
                                validationError = "সঠিক বিক্রয়মূল্য (MRP) লিখুন।"
                                return@Button
                            }
                            val stock = stockQuantityText.toIntOrNull() ?: 0
                            val minStock = minStockAlertText.toIntOrNull() ?: 10

                            val medicine = (initialMedicine ?: MedicineEntity(
                                name = name.trim(),
                                genericName = genericName.trim(),
                                company = company.trim(),
                                category = category,
                                strength = strength.trim(),
                                unit = unit.trim(),
                                purchasePrice = pPrice,
                                mrpPrice = sPrice,
                                stockQuantity = stock,
                                minStockAlert = minStock,
                                batchNumber = batchNumber.trim(),
                                expiryDate = expiryDate.trim(),
                                barcode = barcode.trim(),
                                shelfLocation = shelfLocation.trim()
                            )).copy(
                                name = name.trim(),
                                genericName = genericName.trim(),
                                company = company.trim(),
                                category = category,
                                strength = strength.trim(),
                                unit = unit.trim(),
                                purchasePrice = pPrice,
                                mrpPrice = sPrice,
                                stockQuantity = stock,
                                minStockAlert = minStock,
                                batchNumber = batchNumber.trim(),
                                expiryDate = expiryDate.trim(),
                                barcode = barcode.trim(),
                                shelfLocation = shelfLocation.trim(),
                                updatedAt = System.currentTimeMillis()
                            )

                            onSave(medicine)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1.5f),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        Text(if (initialMedicine == null) "সংরক্ষণ করুন" else "হালনাগাদ করুন")
                    }
                }
            }
        }
    }
}
