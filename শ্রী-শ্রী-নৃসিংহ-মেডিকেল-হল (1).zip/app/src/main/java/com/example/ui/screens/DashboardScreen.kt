package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.automirrored.filled.ReceiptLong
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.PharmacyViewModel
import java.util.Calendar

@Composable
fun DashboardScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val medicines by viewModel.medicines.collectAsStateWithLifecycle()
    val sales by viewModel.sales.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()
    val customers by viewModel.customers.collectAsStateWithLifecycle()
    val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()
    val cashTransactions by viewModel.cashTransactions.collectAsStateWithLifecycle()

    // Calculate Today's Range
    val cal = Calendar.getInstance()
    cal.set(Calendar.HOUR_OF_DAY, 0)
    cal.set(Calendar.MINUTE, 0)
    cal.set(Calendar.SECOND, 0)
    cal.set(Calendar.MILLISECOND, 0)
    val todayStart = cal.timeInMillis

    val todaySales = sales.filter { it.timestamp >= todayStart }
    val todaySalesTotal = todaySales.sumOf { it.grandTotal }
    val todayProfit = todaySales.sumOf { it.totalProfit }

    // Overall metrics
    val totalStockValuation = medicines.sumOf { it.mrpPrice * it.stockQuantity }
    val totalCustomerDue = customers.sumOf { it.currentDue }
    val totalSupplierDue = suppliers.sumOf { it.currentDue }

    val lowStockCount = medicines.count { it.stockQuantity <= it.minStockAlert }
    val expiringCount = medicines.count { viewModel.isMedicineExpiringSoon(it.expiryDate) }
    val expiredCount = medicines.count { viewModel.isMedicineExpired(it.expiryDate) }

    // Net Cash Balance calculation
    val totalIncome = cashTransactions.filter { it.type.startsWith("INCOME") || it.type == "OTHER_INCOME" }.sumOf { it.amount }
    val totalExpense = cashTransactions.filter { it.type.startsWith("EXPENSE") || it.type == "OTHER_EXPENSE" }.sumOf { it.amount }
    val netCashInHand = (totalIncome - totalExpense).coerceAtLeast(0.0)

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 10.dp, bottom = 28.dp)
    ) {
        // 1. Store Header Banner (Clean Minimalism)
        item {
            StoreHeaderBanner()
        }

        // 2. Primary KPI Cards (Mint Green & Warm Coral)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricKpiCard(
                    title = "আজকের বিক্রয়",
                    value = formatCurrency(todaySalesTotal),
                    subtitle = if (todaySales.isNotEmpty()) "${todaySales.size} টি ইনভয়েস" else "+ ০% বৃদ্ধি",
                    icon = Icons.Default.PointOfSale,
                    accentColor = MintCardText,
                    containerColor = MintCardBackground,
                    borderColor = MintCardBorder,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AppScreen.REPORTS) }
                )

                MetricKpiCard(
                    title = "আজকের লাভ",
                    value = formatCurrency(todayProfit),
                    subtitle = if (todaySalesTotal > 0) "লাভ ${((todayProfit / todaySalesTotal) * 100).toInt()}%" else "মোট লাভ ০%",
                    icon = Icons.Default.TrendingUp,
                    accentColor = CoralCardText,
                    containerColor = CoralCardBackground,
                    borderColor = CoralCardBorder,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AppScreen.REPORTS) }
                )
            }
        }

        // Secondary Metrics Row (Cash Drawer & Customer Due)
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                MetricKpiCard(
                    title = "ক্যাশ ব্যালেন্স (ড্রয়ার)",
                    value = formatCurrency(netCashInHand),
                    subtitle = "হাতের নগদ",
                    icon = Icons.Default.AccountBalanceWallet,
                    accentColor = PharmacyGreenPrimary,
                    containerColor = SurfaceCard,
                    borderColor = CardBorderColor,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AppScreen.ACCOUNTING) }
                )

                MetricKpiCard(
                    title = "কাস্টমার বকেয়া",
                    value = formatCurrency(totalCustomerDue),
                    subtitle = "${customers.count { it.currentDue > 0 }} জন বাকিদার",
                    icon = Icons.Default.PeopleAlt,
                    accentColor = RedAlert,
                    containerColor = SurfaceCard,
                    borderColor = CardBorderColor,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(AppScreen.CUSTOMERS) }
                )
            }
        }

        // 3. Quick Action Menu Box (Clean Minimalism Grid)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                border = BorderStroke(1.dp, CardBorderColor),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .width(4.dp)
                                    .height(16.dp)
                                    .clip(RoundedCornerShape(2.dp))
                                    .background(PharmacyGreenPrimary)
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "দ্রুত মেনু",
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 15.sp
                                )
                            )
                        }
                        TextButton(
                            onClick = { viewModel.navigateTo(AppScreen.MEDICINES) },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                text = "সব দেখুন",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = PharmacyGreenPrimary,
                                    fontWeight = FontWeight.Bold
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Grid of 6 Quick Action Buttons (3x2)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        QuickMenuGridButton(
                            title = "বিক্রয় (POS)",
                            emoji = "🛒",
                            bgColor = PastelGreen,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.navigateTo(AppScreen.POS_SALE) }
                        )
                        QuickMenuGridButton(
                            title = "ইনভেন্টরি",
                            emoji = "📦",
                            bgColor = PastelBlue,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                viewModel.stockTabFilter = "ALL"
                                viewModel.navigateTo(AppScreen.MEDICINES)
                            }
                        )
                        QuickMenuGridButton(
                            title = "হিসাব",
                            emoji = "📊",
                            bgColor = PastelOrange,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.navigateTo(AppScreen.ACCOUNTING) }
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        QuickMenuGridButton(
                            title = "কাস্টমার",
                            emoji = "👥",
                            bgColor = PastelPurple,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.navigateTo(AppScreen.CUSTOMERS) }
                        )
                        QuickMenuGridButton(
                            title = "রিপোর্ট",
                            emoji = "📉",
                            bgColor = PastelTeal,
                            modifier = Modifier.weight(1f),
                            onClick = { viewModel.navigateTo(AppScreen.REPORTS) }
                        )
                        QuickMenuGridButton(
                            title = "মেয়াদ শেষ",
                            emoji = "⚠️",
                            bgColor = PastelRed,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                viewModel.stockTabFilter = "EXPIRING_SOON"
                                viewModel.navigateTo(AppScreen.MEDICINES)
                            }
                        )
                    }
                }
            }
        }

        // 4. Dark Stock Alert Card (Clean Minimalism Alert Banner)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = DarkAlertBackground)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "স্টক এলার্ট",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.White.copy(alpha = 0.75f),
                                fontWeight = FontWeight.Medium
                            )
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = if (lowStockCount > 0) "${lowStockCount}টি ওষুধের স্টক কম আছে!" else "সমস্ত ওষুধের পর্যাপ্ত স্টক আছে",
                            style = MaterialTheme.typography.bodyMedium.copy(
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        )
                    }

                    Button(
                        onClick = {
                            viewModel.stockTabFilter = if (lowStockCount > 0) "LOW_STOCK" else "ALL"
                            viewModel.navigateTo(AppScreen.MEDICINES)
                        },
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = DarkAlertPill,
                            contentColor = DarkAlertPillText
                        ),
                        contentPadding = PaddingValues(horizontal = 16.dp, vertical = 8.dp)
                    ) {
                        Text(
                            text = "দেখুন",
                            style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
                        )
                    }
                }
            }
        }

        // 5. Cloud Backup & Sync Bar
        item {
            Surface(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                color = SurfaceCard,
                border = BorderStroke(1.dp, CardBorderColor)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(GreenSuccess)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "লোকাল ও ক্লাউড ব্যাকআপ সক্রিয়",
                                style = MaterialTheme.typography.labelMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = PharmacyGreenDark
                                )
                            )
                            Text(
                                text = "মোবাইল নষ্ট হলেও ডাটা সুরক্ষিত থাকবে",
                                style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary, fontSize = 11.sp)
                            )
                        }
                    }

                    FilledTonalButton(
                        onClick = { viewModel.triggerCloudSync() },
                        shape = RoundedCornerShape(12.dp),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = PharmacyGreenPrimary,
                            contentColor = Color.White
                        )
                    ) {
                        if (viewModel.isCloudSyncing) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(14.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                        } else {
                            Icon(
                                imageVector = Icons.Default.CloudSync,
                                contentDescription = null,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("সিঙ্ক", fontSize = 12.sp)
                    }
                }
            }
        }

        // 6. Recent Sales Invoices
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .width(4.dp)
                            .height(16.dp)
                            .clip(RoundedCornerShape(2.dp))
                            .background(PharmacyGreenPrimary)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "সাম্প্রতিক বিক্রয় মেমো",
                        style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, fontSize = 15.sp)
                    )
                }
                TextButton(onClick = { viewModel.navigateTo(AppScreen.REPORTS) }) {
                    Text("সব দেখুন", color = PharmacyGreenPrimary, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = null,
                        tint = PharmacyGreenPrimary,
                        modifier = Modifier.size(14.dp)
                    )
                }
            }
        }

        if (sales.isEmpty()) {
            item {
                EmptyStateCard(
                    icon = Icons.AutoMirrored.Filled.ReceiptLong,
                    title = "কোন বিক্রয় রেকর্ড নেই",
                    description = "POS কাউন্টার থেকে নতুন বিক্রয় শুরু করুন।"
                )
            }
        } else {
            items(sales.take(5)) { sale ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.lastCompletedInvoice = sale
                            viewModel.lastCompletedCartItems = emptyList()
                            viewModel.showReceiptModal = true
                        },
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                    border = BorderStroke(1.dp, CardBorderColor),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(PharmacyGreenContainer),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Receipt,
                                    contentDescription = null,
                                    tint = PharmacyGreenPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = sale.customerName,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    text = "${sale.invoiceNumber} • ${formatDate(sale.timestamp)}",
                                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                )
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(
                                text = formatCurrency(sale.grandTotal),
                                style = MaterialTheme.typography.titleSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = PharmacyGreenDark
                                )
                            )
                            if (sale.dueAmount > 0) {
                                Text(
                                    text = "বাকি: " + formatCurrency(sale.dueAmount),
                                    style = MaterialTheme.typography.labelSmall.copy(
                                        color = RedAlert,
                                        fontWeight = FontWeight.Bold
                                    )
                                )
                            } else {
                                Text(
                                    text = "পরিশোধ (${sale.paymentMethod})",
                                    style = MaterialTheme.typography.labelSmall.copy(color = GreenSuccess)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun QuickMenuGridButton(
    title: String,
    emoji: String,
    bgColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Column(
        modifier = modifier
            .clickable { onClick() }
            .padding(horizontal = 4.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(54.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(bgColor),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = emoji,
                fontSize = 22.sp
            )
        }
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = title,
            style = MaterialTheme.typography.labelSmall.copy(
                fontWeight = FontWeight.Bold,
                color = TextSecondary,
                fontSize = 11.sp
            ),
            textAlign = TextAlign.Center,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
    }
}

