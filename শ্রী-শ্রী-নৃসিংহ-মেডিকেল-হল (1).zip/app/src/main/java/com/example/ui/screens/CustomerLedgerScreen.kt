package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.CustomerEntity
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PharmacyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CustomerLedgerScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val customers by viewModel.customers.collectAsStateWithLifecycle()

    var showAddCustomerDialog by remember { mutableStateOf(false) }
    var customerToCollectDue by remember { mutableStateOf<CustomerEntity?>(null) }
    var customerToEdit by remember { mutableStateOf<CustomerEntity?>(null) }
    var customerToDelete by remember { mutableStateOf<CustomerEntity?>(null) }

    val filteredCustomers = remember(customers, viewModel.customerSearchQuery) {
        customers.filter { cust ->
            viewModel.customerSearchQuery.isBlank() ||
                    cust.name.contains(viewModel.customerSearchQuery, ignoreCase = true) ||
                    cust.phone.contains(viewModel.customerSearchQuery, ignoreCase = true) ||
                    cust.address.contains(viewModel.customerSearchQuery, ignoreCase = true)
        }
    }

    val totalCustomerDue = customers.sumOf { it.currentDue }
    val totalCustomerCount = customers.size
    val dueCustomerCount = customers.count { it.currentDue > 0 }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = {
                    customerToEdit = null
                    showAddCustomerDialog = true
                },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.PersonAdd, contentDescription = "Add Customer")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("নতুন কাস্টমার যোগ", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Search Bar
            OutlinedTextField(
                value = viewModel.customerSearchQuery,
                onValueChange = { viewModel.customerSearchQuery = it },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 10.dp),
                placeholder = { Text("কাস্টমারের নাম বা মোবাইল নম্বর খুঁজুন...") },
                leadingIcon = {
                    Icon(imageVector = Icons.Default.Search, contentDescription = null, tint = EmeraldPrimary)
                },
                trailingIcon = {
                    if (viewModel.customerSearchQuery.isNotEmpty()) {
                        IconButton(onClick = { viewModel.customerSearchQuery = "" }) {
                            Icon(imageVector = Icons.Default.Clear, contentDescription = "Clear")
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(12.dp)
            )

            // Total Due Summary Banner
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 10.dp),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = RedAlertContainer)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "মোট কাস্টমার বকেয়া (বাকি)",
                            style = MaterialTheme.typography.labelMedium.copy(color = TextSecondary)
                        )
                        Text(
                            text = formatCurrency(totalCustomerDue),
                            style = MaterialTheme.typography.titleLarge.copy(
                                fontWeight = FontWeight.Bold,
                                color = RedAlert
                            )
                        )
                    }
                    Surface(
                        color = Color.White.copy(alpha = 0.8f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text(
                            text = "$dueCustomerCount জন বাকিদার / $totalCustomerCount জন গ্রাহক",
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = TextPrimary)
                        )
                    }
                }
            }

            // Customer List
            if (filteredCustomers.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.PeopleAlt,
                    title = "কোন কাস্টমার পাওয়া যায়নি",
                    description = "নতুন কাস্টমার যুক্ত করতে নিচের বাটনে চাপুন।"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(filteredCustomers, key = { it.id }) { customer ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Box(
                                            modifier = Modifier
                                                .size(42.dp)
                                                .clip(CircleShape)
                                                .background(if (customer.currentDue > 0) RedAlertContainer else EmeraldContainer),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(
                                                imageVector = Icons.Default.Person,
                                                contentDescription = null,
                                                tint = if (customer.currentDue > 0) RedAlert else EmeraldPrimary,
                                                modifier = Modifier.size(24.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = customer.name,
                                                style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold)
                                            )
                                            if (customer.phone.isNotBlank()) {
                                                Text(
                                                    text = "📱 ${customer.phone}",
                                                    style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary)
                                                )
                                            }
                                            if (customer.address.isNotBlank()) {
                                                Text(
                                                    text = "📍 ${customer.address}",
                                                    style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                                )
                                            }
                                        }
                                    }

                                    Column(horizontalAlignment = Alignment.End) {
                                        if (customer.currentDue > 0) {
                                            Text(
                                                text = "বাকি: " + formatCurrency(customer.currentDue),
                                                style = MaterialTheme.typography.titleSmall.copy(
                                                    fontWeight = FontWeight.Bold,
                                                    color = RedAlert
                                                )
                                            )
                                        } else {
                                            Text(
                                                text = "কোন বাকি নেই",
                                                style = MaterialTheme.typography.labelSmall.copy(
                                                    color = GreenSuccess,
                                                    fontWeight = FontWeight.Bold
                                                )
                                            )
                                        }
                                        Text(
                                            text = "মোট কেনাকাটা: ${formatCurrency(customer.totalPurchases)}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                        )
                                    }
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = DividerColor)

                                // Actions (Call, Due Collect, SMS Reminder, Edit, Delete)
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        if (customer.phone.isNotBlank()) {
                                            FilledTonalIconButton(
                                                onClick = {
                                                    val callIntent = Intent(Intent.ACTION_DIAL, Uri.parse("tel:${customer.phone}"))
                                                    context.startActivity(callIntent)
                                                },
                                                modifier = Modifier.size(34.dp),
                                                shape = CircleShape
                                            ) {
                                                Icon(imageVector = Icons.Default.Call, contentDescription = "Call", tint = EmeraldPrimary, modifier = Modifier.size(16.dp))
                                            }

                                            if (customer.currentDue > 0) {
                                                FilledTonalIconButton(
                                                    onClick = {
                                                        val smsMsg = "শ্রদ্ধেয় ${customer.name}, শ্রী শ্রী নৃসিংহ মেডিকেল হল (প্রো: প্রদীপ চন্দ্র হাওলাদার)-এ আপনার পূর্বের ঔষধের বকেয়া বাকি আছে ${formatCurrency(customer.currentDue)}। অনুগ্রহ করে পরিশোধের ব্যবস্থা করার অনুরোধ জানাচ্ছি। ধন্যবাদ!"
                                                        val smsIntent = Intent(Intent.ACTION_VIEW).apply {
                                                            data = Uri.parse("sms:${customer.phone}")
                                                            putExtra("sms_body", smsMsg)
                                                        }
                                                        context.startActivity(smsIntent)
                                                    },
                                                    modifier = Modifier.size(34.dp),
                                                    shape = CircleShape
                                                ) {
                                                    Icon(imageVector = Icons.Default.Message, contentDescription = "SMS Reminder", tint = CyanAccent, modifier = Modifier.size(16.dp))
                                                }
                                            }
                                        }

                                        IconButton(onClick = {
                                            customerToEdit = customer
                                            showAddCustomerDialog = true
                                        }, modifier = Modifier.size(34.dp)) {
                                            Icon(imageVector = Icons.Default.Edit, contentDescription = "Edit", tint = TextSecondary, modifier = Modifier.size(16.dp))
                                        }

                                        IconButton(onClick = {
                                            customerToDelete = customer
                                        }, modifier = Modifier.size(34.dp)) {
                                            Icon(imageVector = Icons.Default.DeleteOutline, contentDescription = "Delete", tint = RedAlert, modifier = Modifier.size(16.dp))
                                        }
                                    }

                                    if (customer.currentDue > 0) {
                                        Button(
                                            onClick = { customerToCollectDue = customer },
                                            shape = RoundedCornerShape(8.dp),
                                            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = GreenSuccess)
                                        ) {
                                            Icon(imageVector = Icons.Default.Payments, contentDescription = null, modifier = Modifier.size(16.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("বাকি আদায়", fontSize = 12.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    if (showAddCustomerDialog) {
        AddCustomerDialog(
            initialCustomer = customerToEdit,
            onDismiss = {
                showAddCustomerDialog = false
                customerToEdit = null
            },
            onSave = { updatedCust ->
                viewModel.saveCustomer(updatedCust)
            }
        )
    }

    if (customerToCollectDue != null) {
        val cust = customerToCollectDue!!
        CollectDueDialog(
            partyName = cust.name,
            currentDue = cust.currentDue,
            isCustomer = true,
            onDismiss = { customerToCollectDue = null },
            onConfirm = { amount, note ->
                viewModel.collectCustomerDue(cust.id, amount, cust.name, note)
                customerToCollectDue = null
            }
        )
    }

    if (customerToDelete != null) {
        AlertDialog(
            onDismissRequest = { customerToDelete = null },
            title = { Text("কাস্টমার মুছে ফেলতে চান?") },
            text = { Text("${customerToDelete?.name}-কে তালিকা থেকে মুছে ফেলা হবে।") },
            confirmButton = {
                Button(
                    onClick = {
                        customerToDelete?.let { viewModel.deleteCustomer(it) }
                        customerToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = RedAlert)
                ) {
                    Text("মুছে ফেলুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { customerToDelete = null }) {
                    Text("বাতিল")
                }
            }
        )
    }
}
