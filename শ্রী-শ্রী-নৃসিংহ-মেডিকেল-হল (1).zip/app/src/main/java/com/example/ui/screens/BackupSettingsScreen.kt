package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PharmacyViewModel

@Composable
fun BackupSettingsScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var showRestoreDialog by remember { mutableStateOf(false) }
    var showExportDialog by remember { mutableStateOf(false) }
    var exportedJsonText by remember { mutableStateOf("") }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 32.dp)
    ) {
        // Store Identity Profile Card
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(18.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(EmeraldContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalPharmacy,
                                contentDescription = null,
                                tint = EmeraldPrimary,
                                modifier = Modifier.size(28.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "শ্রী শ্রী নৃসিংহ মেডিকেল হল",
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = EmeraldDark)
                            )
                            Text(
                                text = "প্রোপ্রাইটর: প্রদীপ চন্দ্র হাওলাদার",
                                style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                            )
                        }
                    }

                    HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = DividerColor)

                    ProfileItem(icon = Icons.Default.Phone, label = "মোবাইল নম্বর", value = "০১৭৩৯০৯৭৩৯০")
                    Spacer(modifier = Modifier.height(6.dp))
                    ProfileItem(icon = Icons.Default.LocationOn, label = "ঠিকানা", value = "গ্রাম + পোস্ট: সোনাখালী, থানা: আমতলী, জেলা: বরগুনা, বাংলাদেশ")
                }
            }
        }

        // Disaster Recovery Guide
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = EmeraldContainer.copy(alpha = 0.5f)),
                border = androidx.compose.foundation.BorderStroke(1.dp, EmeraldPrimary.copy(alpha = 0.3f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Security,
                            contentDescription = null,
                            tint = EmeraldDark,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "মোবাইল নষ্ট বা হারিয়ে গেলে ডাটা রিকভারি নির্দেশিকা",
                            style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold, color = EmeraldDark)
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "১. আপনার সকল হিসাব ও স্টক নিরাপদে সংরক্ষণ করতে নিয়মিত 'ডাটা ব্যাকআপ এক্সপোর্ট' বা 'ক্লাউড সিঙ্ক' করুন।\n\n" +
                                "২. নতুন যেকোনো মোবাইল ফোনে অ্যাপটি চালু করে 'ডাটা রিস্টোর' অপশনে ব্যাকআপ পেস্ট করলে মুহূর্তের মধ্যে আপনার সকল ঔষধের স্টক, কাস্টমার বাকি খাতা ও ক্যাশ মেমো অক্ষত অবস্থায় ফিরে আসবে!\n\n" +
                                "৩. ব্যাকআপ ফাইলটি আপনি আপনার নিজের Google Drive, WhatsApp অথবা Gmail-এ নিরাপদে ড্রাফট বা সেন্ড করে রেখে দিতে পারেন।",
                        style = MaterialTheme.typography.bodySmall.copy(lineHeight = 20.sp, color = TextPrimary)
                    )
                }
            }
        }

        // Backup & Restore Actions
        item {
            Text(
                text = "ডাটা ব্যাকআপ ও রিস্টোর নিয়ন্ত্রণ",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        // Action 1: Cloud Sync
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(EmeraldContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.CloudSync, contentDescription = null, tint = EmeraldPrimary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("ক্লাউড ব্যাকআপ সিঙ্ক", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text("সার্ভারে ডাটা স্বয়ংক্রিয় ব্যাকআপ", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                        }
                    }

                    Button(
                        onClick = { viewModel.triggerCloudSync() },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                    ) {
                        if (viewModel.isCloudSyncing) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Text("সিঙ্ক করুন")
                        }
                    }
                }
            }
        }

        // Action 2: Export JSON Backup
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(CyanAccentContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Download, contentDescription = null, tint = CyanAccent)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("ডাটা ব্যাকআপ এক্সপোর্ট", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text("পুরো ডাটাবেজ ফাইল আকারে সংরক্ষণ", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                        }
                    }

                    FilledTonalButton(
                        onClick = {
                            viewModel.exportBackupJson { json ->
                                exportedJsonText = json
                                showExportDialog = true
                            }
                        },
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(containerColor = CyanAccentContainer, contentColor = CyanAccent)
                    ) {
                        Text("এক্সপোর্ট")
                    }
                }
            }
        }

        // Action 3: Restore Database
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCard)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(AmberWarningContainer),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(imageVector = Icons.Default.Restore, contentDescription = null, tint = AmberWarning)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("ডাটা রিস্টোর / ফিরিয়ে আনুন", style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                            Text("ব্যাকআপ ফাইল থেকে সকল ডাটা লোড", style = MaterialTheme.typography.labelSmall.copy(color = TextSecondary))
                        }
                    }

                    OutlinedButton(
                        onClick = { showRestoreDialog = true },
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Text("রিস্টোর")
                    }
                }
            }
        }

        // App Information
        item {
            Text(
                text = "অ্যাপ তথ্য ও ভার্সন",
                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
                modifier = Modifier.padding(top = 8.dp)
            )
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = SurfaceCardAlt)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("অ্যাপ সংস্করণ:", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                        Text("v2.5.0 (Nrisingha Pharmacy Suite)", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ডাটাবেজ সিস্টেম:", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                        Text("Android Room SQLite + Offline-First", style = MaterialTheme.typography.bodySmall)
                    }
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("ফার্মেসি রেজিস্ট্রেশন:", style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary))
                        Text("সোনাখালী, আমতলী, বরগুনা", style = MaterialTheme.typography.bodySmall)
                    }
                }
            }
        }
    }

    // Export Dialog
    if (showExportDialog) {
        AlertDialog(
            onDismissRequest = { showExportDialog = false },
            title = { Text("ব্যাকআপ ডাটা প্রস্তুত", fontWeight = FontWeight.Bold) },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("আপনার ডাটাবেজের সকল ঔষধ, স্টক, ক্রেতা ও হিসাব এনকোড করা হয়েছে। এটি কপি করে গুগল ড্রাইভ বা হোয়াটস্যাপে রেখে দিন।")
                    OutlinedTextField(
                        value = exportedJsonText.take(200) + "... (মোট ${exportedJsonText.length} অক্ষর)",
                        onValueChange = {},
                        readOnly = true,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                        val clip = ClipData.newPlainText("NrisinghaBackup", exportedJsonText)
                        clipboard.setPrimaryClip(clip)
                        Toast.makeText(context, "ব্যাকআপ কোড ক্লিপবোর্ডে কপি হয়েছে!", Toast.LENGTH_LONG).show()

                        // Share Intent
                        val sendIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(Intent.EXTRA_SUBJECT, "Nrisingha_Medical_Backup.json")
                            putExtra(Intent.EXTRA_TEXT, exportedJsonText)
                        }
                        context.startActivity(Intent.createChooser(sendIntent, "ব্যাকআপ ফাইল শেয়ার করুন"))
                        showExportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                ) {
                    Icon(imageVector = Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("কপি ও শেয়ার করুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showExportDialog = false }) {
                    Text("বন্ধ করুন")
                }
            }
        )
    }

    // Restore Dialog
    if (showRestoreDialog) {
        var restoreInputText by remember { mutableStateOf("") }
        var restoreError by remember { mutableStateOf<String?>(null) }

        Dialog(onDismissRequest = { showRestoreDialog = false }) {
            Surface(
                modifier = Modifier.fillMaxWidth(0.92f),
                shape = RoundedCornerShape(16.dp),
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("ডাটা রিস্টোর করুন", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        IconButton(onClick = { showRestoreDialog = false }) {
                            Icon(imageVector = Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    Text(
                        text = "পূর্বে সংরক্ষিত ব্যাকআপ কোড বা JSON টেক্সট এখানে পেস্ট করুন:",
                        style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                    )

                    if (restoreError != null) {
                        Text(restoreError ?: "", color = RedAlert, style = MaterialTheme.typography.bodySmall)
                    }

                    OutlinedTextField(
                        value = restoreInputText,
                        onValueChange = { restoreInputText = it; restoreError = null },
                        placeholder = { Text("ব্যাকআপ JSON পেস্ট করুন...") },
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(130.dp),
                        maxLines = 6
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                val clip = clipboard.primaryClip
                                if (clip != null && clip.itemCount > 0) {
                                    restoreInputText = clip.getItemAt(0).text.toString()
                                }
                            },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text("পেস্ট করুন")
                        }

                        Button(
                            onClick = {
                                if (restoreInputText.isBlank()) {
                                    restoreError = "অনুগ্রহ করে ব্যাকআপ টেক্সট পেস্ট করুন।"
                                    return@Button
                                }
                                viewModel.restoreBackupJson(restoreInputText) { success, msg ->
                                    if (success) {
                                        Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
                                        showRestoreDialog = false
                                    } else {
                                        restoreError = msg
                                    }
                                }
                            },
                            modifier = Modifier.weight(1.3f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
                        ) {
                            Text("রিস্টোর করুন")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun ProfileItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    value: String
) {
    Row(
        verticalAlignment = Alignment.Top,
        modifier = Modifier.fillMaxWidth()
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = EmeraldPrimary,
            modifier = Modifier
                .size(20.dp)
                .padding(top = 2.dp)
        )
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(text = label, style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary))
            Text(text = value, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Medium))
        }
    }
}
