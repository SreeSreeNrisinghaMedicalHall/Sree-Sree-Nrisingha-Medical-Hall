package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.*
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.PharmacyViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PurchaseScreen(
    viewModel: PharmacyViewModel,
    modifier: Modifier = Modifier
) {
    val suppliers by viewModel.suppliers.collectAsStateWithLifecycle()
    val medicines by viewModel.medicines.collectAsStateWithLifecycle()
    val purchases by viewModel.purchases.collectAsStateWithLifecycle()

    var showNewPurchaseDialog by remember { mutableStateOf(false) }

    Scaffold(
        modifier = modifier.fillMaxSize(),
        floatingActionButton = {
            FloatingActionButton(
                onClick = { showNewPurchaseDialog = true },
                containerColor = EmeraldPrimary,
                contentColor = Color.White,
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = "New Purchase")
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("নতুন চালান / ক্রয় এন্ট্রি", fontWeight = FontWeight.Bold)
                }
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 16.dp)
        ) {
            // Purchase History Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 12.dp, bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "কোম্পানি চালান ও ক্রয় ইতিহাস",
                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                )
                Text(
                    text = "মোট চালান: ${purchases.size}",
                    style = MaterialTheme.typography.bodySmall.copy(color = TextSecondary)
                )
            }

            if (purchases.isEmpty()) {
                EmptyStateCard(
                    icon = Icons.Default.Inventory,
                    title = "কোন ক্রয় চালান রেকর্ড নেই",
                    description = "কোম্পানি থেকে ঔষধ ক্রয় চালান যুক্ত করতে নিচের বাটনে চাপুন।"
                )
            } else {
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp),
                    contentPadding = PaddingValues(bottom = 80.dp)
                ) {
                    items(purchases) { purchase ->
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(14.dp),
                            colors = CardDefaults.cardColors(containerColor = SurfaceCard),
                            elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(14.dp)
                            ) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Text(
                                            text = purchase.supplierName,
                                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                        )
                                        Text(
                                            text = "চালান নং: ${purchase.invoiceNumber} • ${formatDate(purchase.timestamp)}",
                                            style = MaterialTheme.typography.labelSmall.copy(color = TextTertiary)
                                        )
                                    }
                                    Text(
                                        text = formatCurrency(purchase.totalAmount),
                                        style = MaterialTheme.typography.titleMedium.copy(
                                            fontWeight = FontWeight.Bold,
                                            color = EmeraldDark
                                        )
                                    )
                                }

                                HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp), color = DividerColor)

                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        text = "পরিশোধ: ${formatCurrency(purchase.paidAmount)}",
                                        style = MaterialTheme.typography.bodySmall.copy(color = GreenSuccess, fontWeight = FontWeight.SemiBold)
                                    )
                                    if (purchase.dueAmount > 0) {
                                        Text(
                                            text = "কোম্পানি বাকি: ${formatCurrency(purchase.dueAmount)}",
                                            style = MaterialTheme.typography.bodySmall.copy(color = RedAlert, fontWeight = FontWeight.Bold)
                                        )
                                    } else {
                                        Text(
                                            text = "পরিশোধ সম্পন্ন",
                                            style = MaterialTheme.typography.bodySmall.copy(color = GreenSuccess)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // New Purchase Invoice Dialog
    if (showNewPurchaseDialog) {
        NewPurchaseDialog(
            suppliers = suppliers,
            medicines = medicines,
            onDismiss = { showNewPurchaseDialog = false },
            onSave = { supplier, items, paid, note ->
                viewModel.recordPurchase(supplier, items, paid, note)
                showNewPurchaseDialog = false
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun NewPurchaseDialog(
    suppliers: List<SupplierEntity>,
    medicines: List<MedicineEntity>,
    onDismiss: () -> Unit,
    onSave: (SupplierEntity, List<CartItem>, Double, String) -> Unit
) {
    var selectedSupplier by remember { mutableStateOf<SupplierEntity?>(suppliers.firstOrNull()) }
    var supplierDropdownExpanded by remember { mutableStateOf(false) }

    val purchaseItems = remember { mutableStateListOf<CartItem>() }
    var selectedMedicineToAdd by remember { mutableStateOf<MedicineEntity?>(medicines.firstOrNull()) }
    var medicineDropdownExpanded by remember { mutableStateOf(false) }

    var addQuantityText by remember { mutableStateOf("10") }
    var addPriceText by remember { mutableStateOf(medicines.firstOrNull()?.purchasePrice?.toString() ?: "10.0") }
    var addBatchText by remember { mutableStateOf("B-2026") }
    var addExpiryText by remember { mutableStateOf("2028-12-31") }

    var paidAmountText by remember { mutableStateOf("") }
    var note by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val totalAmount = purchaseItems.sumOf { it.purchasePrice * it.quantity }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.AddShoppingCart, contentDescription = null, tint = EmeraldPrimary)
                Spacer(modifier = Modifier.width(8.dp))
                Text("কোম্পানি থেকে ঔষধ ক্রয় এন্ট্রি", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 500.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                if (error != null) {
                    Text(error ?: "", color = RedAlert, style = MaterialTheme.typography.bodySmall)
                }

                // Supplier Dropdown
                ExposedDropdownMenuBox(
                    expanded = supplierDropdownExpanded,
                    onExpandedChange = { supplierDropdownExpanded = !supplierDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedSupplier?.companyName ?: "সাপ্লায়ার নির্বাচন করুন",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("সাপ্লায়ার / কোম্পানি *") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = supplierDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = supplierDropdownExpanded,
                        onDismissRequest = { supplierDropdownExpanded = false }
                    ) {
                        suppliers.forEach { supp ->
                            DropdownMenuItem(
                                text = { Text(supp.companyName) },
                                onClick = {
                                    selectedSupplier = supp
                                    supplierDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))

                Text("আইটেম যোগ করুন:", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))

                // Select Medicine
                ExposedDropdownMenuBox(
                    expanded = medicineDropdownExpanded,
                    onExpandedChange = { medicineDropdownExpanded = !medicineDropdownExpanded },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    OutlinedTextField(
                        value = selectedMedicineToAdd?.name ?: "ঔষধ নির্বাচন করুন",
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("ঔষধ") },
                        trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = medicineDropdownExpanded) },
                        modifier = Modifier
                            .menuAnchor()
                            .fillMaxWidth()
                    )
                    ExposedDropdownMenu(
                        expanded = medicineDropdownExpanded,
                        onDismissRequest = { medicineDropdownExpanded = false }
                    ) {
                        medicines.forEach { med ->
                            DropdownMenuItem(
                                text = { Text("${med.name} (${med.strength})") },
                                onClick = {
                                    selectedMedicineToAdd = med
                                    addPriceText = med.purchasePrice.toString()
                                    medicineDropdownExpanded = false
                                }
                            )
                        }
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = addQuantityText,
                        onValueChange = { addQuantityText = it },
                        label = { Text("পরিমাণ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                    OutlinedTextField(
                        value = addPriceText,
                        onValueChange = { addPriceText = it },
                        label = { Text("ক্রয়মূল্য (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.weight(1f),
                        singleLine = true
                    )
                }

                Button(
                    onClick = {
                        val med = selectedMedicineToAdd ?: return@Button
                        val qty = addQuantityText.toIntOrNull() ?: 1
                        val price = addPriceText.toDoubleOrNull() ?: med.purchasePrice
                        purchaseItems.add(
                            CartItem(
                                medicineId = med.id,
                                name = med.name,
                                genericName = med.genericName,
                                strength = med.strength,
                                unit = med.unit,
                                unitPrice = med.mrpPrice,
                                purchasePrice = price,
                                quantity = qty,
                                stockAvailable = med.stockQuantity,
                                batchNumber = addBatchText,
                                expiryDate = addExpiryText
                            )
                        )
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = CyanAccent)
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("চালানে আইটেম যোগ")
                }

                // Purchase Items List
                if (purchaseItems.isNotEmpty()) {
                    Text(
                        text = "মোট আইটেম: ${purchaseItems.size} (মোট চালান: ${formatCurrency(totalAmount)})",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, color = EmeraldDark)
                    )

                    purchaseItems.forEachIndexed { index, item ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clip(RoundedCornerShape(6.dp))
                                .background(SurfaceCardAlt)
                                .padding(6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text("${item.name} (${item.quantity} ${item.unit})", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold))
                                Text("@ ${formatCurrency(item.purchasePrice)} = ${formatCurrency(item.purchasePrice * item.quantity)}", style = MaterialTheme.typography.labelSmall)
                            }
                            IconButton(onClick = { purchaseItems.removeAt(index) }, modifier = Modifier.size(24.dp)) {
                                Icon(imageVector = Icons.Default.Close, contentDescription = "Remove", tint = RedAlert, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    OutlinedTextField(
                        value = paidAmountText,
                        onValueChange = { paidAmountText = it },
                        label = { Text("নগদ পরিশোধের পরিমাণ (৳)") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val supp = selectedSupplier
                    if (supp == null) {
                        error = "সাপ্লায়ার নির্বাচন করুন।"
                        return@Button
                    }
                    if (purchaseItems.isEmpty()) {
                        error = "কমপক্ষে একটি আইটেম যোগ করুন।"
                        return@Button
                    }
                    val paid = paidAmountText.toDoubleOrNull() ?: totalAmount
                    onSave(supp, purchaseItems.toList(), paid, note)
                },
                colors = ButtonDefaults.buttonColors(containerColor = EmeraldPrimary)
            ) {
                Text("চালান সংরক্ষণ করুন")
            }
        },
        dismissButton = {
            OutlinedButton(onClick = onDismiss) {
                Text("বাতিল")
            }
        }
    )
}
