package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        MedicineEntity::class,
        CustomerEntity::class,
        SupplierEntity::class,
        SaleInvoiceEntity::class,
        PurchaseInvoiceEntity::class,
        CashTransactionEntity::class,
        ReturnRecordEntity::class,
        PrescriptionEntity::class,
        StaffUserEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class PharmacyDatabase : RoomDatabase() {
    abstract fun pharmacyDao(): PharmacyDao

    companion object {
        @Volatile
        private var INSTANCE: PharmacyDatabase? = null

        fun getDatabase(
            context: Context,
            scope: CoroutineScope = CoroutineScope(Dispatchers.IO)
        ): PharmacyDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    PharmacyDatabase::class.java,
                    "nrisingha_pharmacy_db"
                )
                .addCallback(PharmacyDatabaseCallback(scope))
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }

        private class PharmacyDatabaseCallback(
            private val scope: CoroutineScope
        ) : RoomDatabase.Callback() {
            override fun onCreate(db: SupportSQLiteDatabase) {
                super.onCreate(db)
                INSTANCE?.let { database ->
                    scope.launch(Dispatchers.IO) {
                        populateInitialData(database.pharmacyDao())
                    }
                }
            }

            suspend fun populateInitialData(dao: PharmacyDao) {
                dao.insertAllMedicines(SampleData.initialMedicines)
                dao.insertAllCustomers(SampleData.initialCustomers)
                dao.insertAllSuppliers(SampleData.initialSuppliers)
                dao.insertAllStaff(SampleData.initialStaff)

                // Add sample today's cash transaction for opening balance
                dao.insertCashTransaction(
                    CashTransactionEntity(
                        type = "OTHER_INCOME",
                        category = "Opening Balance",
                        amount = 5000.0,
                        title = "আজকের প্রারম্ভিক ক্যাশ (Opening Cash)",
                        note = "Daily opening drawer float",
                        timestamp = System.currentTimeMillis() - 3600000 * 4
                    )
                )
            }
        }
    }
}
