package com.example.data

import kotlinx.coroutines.flow.Flow
import org.json.JSONArray
import org.json.JSONObject

class PharmacyRepository(private val dao: PharmacyDao) {

    // --- Medicines ---
    val allMedicines: Flow<List<MedicineEntity>> = dao.getAllMedicines()
    val lowStockMedicines: Flow<List<MedicineEntity>> = dao.getLowStockMedicines()

    fun searchMedicines(query: String): Flow<List<MedicineEntity>> = dao.searchMedicines(query)

    suspend fun getMedicineById(id: Long) = dao.getMedicineById(id)

    suspend fun insertMedicine(medicine: MedicineEntity) = dao.insertMedicine(medicine)

    suspend fun updateMedicine(medicine: MedicineEntity) = dao.updateMedicine(medicine)

    suspend fun deleteMedicine(medicine: MedicineEntity) = dao.deleteMedicine(medicine)

    // --- Customers ---
    val allCustomers: Flow<List<CustomerEntity>> = dao.getAllCustomers()

    suspend fun insertCustomer(customer: CustomerEntity) = dao.insertCustomer(customer)

    suspend fun updateCustomer(customer: CustomerEntity) = dao.updateCustomer(customer)

    suspend fun deleteCustomer(customer: CustomerEntity) = dao.deleteCustomer(customer)

    suspend fun collectCustomerDue(customerId: Long, amount: Double, customerName: String, note: String) {
        dao.deductCustomerDue(customerId, amount)
        dao.insertCashTransaction(
            CashTransactionEntity(
                type = "INCOME_DUE",
                category = "Due Collection",
                amount = amount,
                title = "বাকি আদায়: $customerName",
                referenceId = "CUST-$customerId",
                note = note
            )
        )
    }

    // --- Suppliers ---
    val allSuppliers: Flow<List<SupplierEntity>> = dao.getAllSuppliers()

    suspend fun insertSupplier(supplier: SupplierEntity) = dao.insertSupplier(supplier)

    suspend fun updateSupplier(supplier: SupplierEntity) = dao.updateSupplier(supplier)

    suspend fun deleteSupplier(supplier: SupplierEntity) = dao.deleteSupplier(supplier)

    suspend fun paySupplierDue(supplierId: Long, amount: Double, supplierName: String, note: String) {
        dao.deductSupplierDue(supplierId, amount)
        dao.insertCashTransaction(
            CashTransactionEntity(
                type = "EXPENSE_SUPPLIER_PAY",
                category = "Supplier Payment",
                amount = amount,
                title = "সাপ্লায়ার পাওনা পরিশোধ: $supplierName",
                referenceId = "SUPP-$supplierId",
                note = note
            )
        )
    }

    // --- Sales ---
    val allSales: Flow<List<SaleInvoiceEntity>> = dao.getAllSales()

    suspend fun completeSale(
        sale: SaleInvoiceEntity,
        items: List<CartItem>
    ): Long {
        // 1. Insert Sale Record
        val saleId = dao.insertSale(sale)

        // 2. Deduct stock for each item
        for (item in items) {
            dao.deductStock(item.medicineId, item.quantity)
        }

        // 3. Update customer ledger if customer attached
        if (sale.customerId != null && sale.customerId > 0) {
            dao.updateCustomerPurchase(
                customerId = sale.customerId,
                purchaseAmount = sale.grandTotal,
                dueAmount = sale.dueAmount
            )
        }

        // 4. Record Cash Income transaction for the paid amount
        if (sale.paidAmount > 0) {
            dao.insertCashTransaction(
                CashTransactionEntity(
                    type = "INCOME_SALE",
                    category = "Sale",
                    amount = sale.paidAmount,
                    title = "বিক্রয় ইনভয়েস: ${sale.invoiceNumber}",
                    referenceId = sale.invoiceNumber,
                    note = "Payment method: ${sale.paymentMethod}. Customer: ${sale.customerName}"
                )
            )
        }

        return saleId
    }

    suspend fun deleteSale(sale: SaleInvoiceEntity) = dao.deleteSale(sale)

    // --- Purchases ---
    val allPurchases: Flow<List<PurchaseInvoiceEntity>> = dao.getAllPurchases()

    suspend fun completePurchase(
        purchase: PurchaseInvoiceEntity,
        items: List<CartItem>
    ): Long {
        val purchaseId = dao.insertPurchase(purchase)

        // Add stock
        for (item in items) {
            dao.addStock(item.medicineId, item.quantity)
        }

        // Update supplier balance
        if (purchase.supplierId > 0) {
            dao.updateSupplierPurchase(
                supplierId = purchase.supplierId,
                purchaseAmount = purchase.totalAmount,
                dueAmount = purchase.dueAmount
            )
        }

        // Record cash expense if paid amount > 0
        if (purchase.paidAmount > 0) {
            dao.insertCashTransaction(
                CashTransactionEntity(
                    type = "EXPENSE_PURCHASE",
                    category = "Purchase",
                    amount = purchase.paidAmount,
                    title = "ওষুধ ক্রয়: ${purchase.invoiceNumber} (${purchase.supplierName})",
                    referenceId = purchase.invoiceNumber,
                    note = "Supplier: ${purchase.supplierName}"
                )
            )
        }

        return purchaseId
    }

    // --- Cash Transactions ---
    val allCashTransactions: Flow<List<CashTransactionEntity>> = dao.getAllCashTransactions()

    suspend fun insertExpense(
        category: String,
        amount: Double,
        title: String,
        note: String
    ) {
        dao.insertCashTransaction(
            CashTransactionEntity(
                type = "EXPENSE_SHOP",
                category = category,
                amount = amount,
                title = title,
                note = note
            )
        )
    }

    suspend fun insertIncome(
        category: String,
        amount: Double,
        title: String,
        note: String
    ) {
        dao.insertCashTransaction(
            CashTransactionEntity(
                type = "OTHER_INCOME",
                category = category,
                amount = amount,
                title = title,
                note = note
            )
        )
    }

    suspend fun deleteCashTransaction(transaction: CashTransactionEntity) = dao.deleteCashTransaction(transaction)

    // --- Returns ---
    val allReturns: Flow<List<ReturnRecordEntity>> = dao.getAllReturns()

    suspend fun processReturn(returnRecord: ReturnRecordEntity) {
        dao.insertReturn(returnRecord)
        if (returnRecord.type == "SALE_RETURN") {
            // Customer returned item -> add stock back
            dao.addStock(returnRecord.medicineId, returnRecord.quantity)
            // Record refund expense
            dao.insertCashTransaction(
                CashTransactionEntity(
                    type = "OTHER_EXPENSE",
                    category = "Sales Return Refund",
                    amount = returnRecord.totalAmount,
                    title = "বিক্রয় ফেরত রিফান্ড: ${returnRecord.medicineName}",
                    note = "Quantity: ${returnRecord.quantity}. Party: ${returnRecord.partyName}"
                )
            )
        } else {
            // Purchase return to supplier -> deduct stock
            dao.deductStock(returnRecord.medicineId, returnRecord.quantity)
            // Record return income
            dao.insertCashTransaction(
                CashTransactionEntity(
                    type = "OTHER_INCOME",
                    category = "Purchase Return",
                    amount = returnRecord.totalAmount,
                    title = "ক্রয় ফেরত টাকা প্রাপ্তি: ${returnRecord.medicineName}",
                    note = "Quantity: ${returnRecord.quantity}. Supplier: ${returnRecord.partyName}"
                )
            )
        }
    }

    // --- Prescriptions ---
    val allPrescriptions: Flow<List<PrescriptionEntity>> = dao.getAllPrescriptions()

    suspend fun insertPrescription(prescription: PrescriptionEntity) = dao.insertPrescription(prescription)

    suspend fun deletePrescription(prescription: PrescriptionEntity) = dao.deletePrescription(prescription)

    // --- Staff Users ---
    val allStaff: Flow<List<StaffUserEntity>> = dao.getAllStaff()

    suspend fun insertStaff(staff: StaffUserEntity) = dao.insertStaff(staff)

    suspend fun deleteStaff(staff: StaffUserEntity) = dao.deleteStaff(staff)

    // --- Database Backup Export to JSON ---
    suspend fun generateBackupJson(
        medicines: List<MedicineEntity>,
        customers: List<CustomerEntity>,
        suppliers: List<SupplierEntity>,
        sales: List<SaleInvoiceEntity>,
        purchases: List<PurchaseInvoiceEntity>,
        cashTransactions: List<CashTransactionEntity>,
        staff: List<StaffUserEntity>
    ): String {
        val root = JSONObject()
        root.put("appName", "শ্রী শ্রী নৃসিংহ মেডিকেল হল")
        root.put("proprietor", "প্রদীপ চন্দ্র হাওলাদার")
        root.put("phone", "01739097390")
        root.put("address", "সোনাখালী, আমতলী, বরগুনা, বাংলাদেশ")
        root.put("version", "1.0")
        root.put("backupDate", System.currentTimeMillis())

        // Medicines
        val medArray = JSONArray()
        for (m in medicines) {
            val obj = JSONObject()
            obj.put("id", m.id)
            obj.put("name", m.name)
            obj.put("genericName", m.genericName)
            obj.put("company", m.company)
            obj.put("category", m.category)
            obj.put("strength", m.strength)
            obj.put("unit", m.unit)
            obj.put("purchasePrice", m.purchasePrice)
            obj.put("mrpPrice", m.mrpPrice)
            obj.put("stockQuantity", m.stockQuantity)
            obj.put("minStockAlert", m.minStockAlert)
            obj.put("batchNumber", m.batchNumber)
            obj.put("expiryDate", m.expiryDate)
            obj.put("barcode", m.barcode)
            obj.put("shelfLocation", m.shelfLocation)
            medArray.put(obj)
        }
        root.put("medicines", medArray)

        // Customers
        val custArray = JSONArray()
        for (c in customers) {
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("name", c.name)
            obj.put("phone", c.phone)
            obj.put("address", c.address)
            obj.put("totalPurchases", c.totalPurchases)
            obj.put("currentDue", c.currentDue)
            custArray.put(obj)
        }
        root.put("customers", custArray)

        // Suppliers
        val suppArray = JSONArray()
        for (s in suppliers) {
            val obj = JSONObject()
            obj.put("id", s.id)
            obj.put("companyName", s.companyName)
            obj.put("representativeName", s.representativeName)
            obj.put("phone", s.phone)
            obj.put("address", s.address)
            obj.put("currentDue", s.currentDue)
            obj.put("totalPurchased", s.totalPurchased)
            suppArray.put(obj)
        }
        root.put("suppliers", suppArray)

        return root.toString(2)
    }

    suspend fun restoreBackupFromJson(jsonString: String): Boolean {
        return try {
            val root = JSONObject(jsonString)
            if (root.has("medicines")) {
                val medArray = root.getJSONArray("medicines")
                val medList = mutableListOf<MedicineEntity>()
                for (i in 0 until medArray.length()) {
                    val obj = medArray.getJSONObject(i)
                    medList.add(
                        MedicineEntity(
                            id = if (obj.has("id")) obj.getLong("id") else 0,
                            name = obj.getString("name"),
                            genericName = obj.optString("genericName", ""),
                            company = obj.optString("company", ""),
                            category = obj.optString("category", "Tablet"),
                            strength = obj.optString("strength", ""),
                            unit = obj.optString("unit", "Pcs"),
                            purchasePrice = obj.optDouble("purchasePrice", 0.0),
                            mrpPrice = obj.optDouble("mrpPrice", 0.0),
                            stockQuantity = obj.optInt("stockQuantity", 0),
                            minStockAlert = obj.optInt("minStockAlert", 10),
                            batchNumber = obj.optString("batchNumber", ""),
                            expiryDate = obj.optString("expiryDate", ""),
                            barcode = obj.optString("barcode", ""),
                            shelfLocation = obj.optString("shelfLocation", "")
                        )
                    )
                }
                if (medList.isNotEmpty()) {
                    dao.clearMedicines()
                    dao.insertAllMedicines(medList)
                }
            }

            if (root.has("customers")) {
                val custArray = root.getJSONArray("customers")
                val custList = mutableListOf<CustomerEntity>()
                for (i in 0 until custArray.length()) {
                    val obj = custArray.getJSONObject(i)
                    custList.add(
                        CustomerEntity(
                            id = if (obj.has("id")) obj.getLong("id") else 0,
                            name = obj.getString("name"),
                            phone = obj.optString("phone", ""),
                            address = obj.optString("address", ""),
                            totalPurchases = obj.optDouble("totalPurchases", 0.0),
                            currentDue = obj.optDouble("currentDue", 0.0)
                        )
                    )
                }
                if (custList.isNotEmpty()) {
                    dao.clearCustomers()
                    dao.insertAllCustomers(custList)
                }
            }

            if (root.has("suppliers")) {
                val suppArray = root.getJSONArray("suppliers")
                val suppList = mutableListOf<SupplierEntity>()
                for (i in 0 until suppArray.length()) {
                    val obj = suppArray.getJSONObject(i)
                    suppList.add(
                        SupplierEntity(
                            id = if (obj.has("id")) obj.getLong("id") else 0,
                            companyName = obj.getString("companyName"),
                            representativeName = obj.optString("representativeName", ""),
                            phone = obj.optString("phone", ""),
                            address = obj.optString("address", ""),
                            currentDue = obj.optDouble("currentDue", 0.0),
                            totalPurchased = obj.optDouble("totalPurchased", 0.0)
                        )
                    )
                }
                if (suppList.isNotEmpty()) {
                    dao.clearSuppliers()
                    dao.insertAllSuppliers(suppList)
                }
            }

            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
}
