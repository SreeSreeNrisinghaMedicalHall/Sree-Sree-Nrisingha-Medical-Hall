package com.example.data

object SampleData {
    val initialMedicines = listOf(
        MedicineEntity(
            name = "Napa Extra",
            genericName = "Paracetamol + Caffeine",
            company = "Beximco Pharmaceuticals Ltd.",
            category = "Tablet",
            strength = "500 mg + 65 mg",
            unit = "Pcs",
            purchasePrice = 2.40,
            mrpPrice = 3.00,
            stockQuantity = 450,
            minStockAlert = 50,
            batchNumber = "NX-2026B",
            expiryDate = "2028-04-30",
            barcode = "894110010011",
            shelfLocation = "Rack A-1"
        ),
        MedicineEntity(
            name = "Napa 500",
            genericName = "Paracetamol",
            company = "Beximco Pharmaceuticals Ltd.",
            category = "Tablet",
            strength = "500 mg",
            unit = "Pcs",
            purchasePrice = 1.00,
            mrpPrice = 1.25,
            stockQuantity = 800,
            minStockAlert = 100,
            batchNumber = "NP-2026A",
            expiryDate = "2028-01-31",
            barcode = "894110010022",
            shelfLocation = "Rack A-1"
        ),
        MedicineEntity(
            name = "Ace Plus",
            genericName = "Paracetamol + Caffeine",
            company = "Square Pharmaceuticals Ltd.",
            category = "Tablet",
            strength = "500 mg + 65 mg",
            unit = "Pcs",
            purchasePrice = 2.40,
            mrpPrice = 3.00,
            stockQuantity = 320,
            minStockAlert = 40,
            batchNumber = "AP-9921",
            expiryDate = "2027-11-30",
            barcode = "894110010033",
            shelfLocation = "Rack A-2"
        ),
        MedicineEntity(
            name = "Sergel 20",
            genericName = "Esomeprazole Magnesium",
            company = "Healthcare Pharmaceuticals Ltd.",
            category = "Capsule",
            strength = "20 mg",
            unit = "Pcs",
            purchasePrice = 6.20,
            mrpPrice = 8.00,
            stockQuantity = 240,
            minStockAlert = 30,
            batchNumber = "SRG-450",
            expiryDate = "2027-08-31",
            barcode = "894110010044",
            shelfLocation = "Rack B-1"
        ),
        MedicineEntity(
            name = "Seclo 20",
            genericName = "Omeprazole",
            company = "Square Pharmaceuticals Ltd.",
            category = "Capsule",
            strength = "20 mg",
            unit = "Pcs",
            purchasePrice = 4.80,
            mrpPrice = 6.00,
            stockQuantity = 180,
            minStockAlert = 30,
            batchNumber = "SEC-881",
            expiryDate = "2027-09-30",
            barcode = "894110010055",
            shelfLocation = "Rack B-1"
        ),
        MedicineEntity(
            name = "Maxpro 20",
            genericName = "Esomeprazole",
            company = "Renata Limited",
            category = "Tablet",
            strength = "20 mg",
            unit = "Pcs",
            purchasePrice = 6.40,
            mrpPrice = 8.00,
            stockQuantity = 160,
            minStockAlert = 25,
            batchNumber = "MXP-102",
            expiryDate = "2027-10-31",
            barcode = "894110010066",
            shelfLocation = "Rack B-2"
        ),
        MedicineEntity(
            name = "Pantonix 20",
            genericName = "Pantoprazole",
            company = "Incepta Pharmaceuticals Ltd.",
            category = "Tablet",
            strength = "20 mg",
            unit = "Pcs",
            purchasePrice = 5.50,
            mrpPrice = 7.00,
            stockQuantity = 15, // Low stock demo!
            minStockAlert = 30,
            batchNumber = "PTX-304",
            expiryDate = "2026-10-15", // Expiring soon demo!
            barcode = "894110010077",
            shelfLocation = "Rack B-3"
        ),
        MedicineEntity(
            name = "Monas 10",
            genericName = "Montelukast Sodium",
            company = "Acme Laboratories Ltd.",
            category = "Tablet",
            strength = "10 mg",
            unit = "Pcs",
            purchasePrice = 13.00,
            mrpPrice = 16.00,
            stockQuantity = 120,
            minStockAlert = 20,
            batchNumber = "MNS-771",
            expiryDate = "2027-12-31",
            barcode = "894110010088",
            shelfLocation = "Rack C-1"
        ),
        MedicineEntity(
            name = "Fexo 120",
            genericName = "Fexofenadine Hydrochloride",
            company = "Square Pharmaceuticals Ltd.",
            category = "Tablet",
            strength = "120 mg",
            unit = "Pcs",
            purchasePrice = 7.50,
            mrpPrice = 9.50,
            stockQuantity = 140,
            minStockAlert = 20,
            batchNumber = "FX-550",
            expiryDate = "2028-02-28",
            barcode = "894110010099",
            shelfLocation = "Rack C-2"
        ),
        MedicineEntity(
            name = "Ceevit 250",
            genericName = "Ascorbic Acid (Vitamin C)",
            company = "Square Pharmaceuticals Ltd.",
            category = "Tablet",
            strength = "250 mg",
            unit = "Pcs",
            purchasePrice = 1.60,
            mrpPrice = 2.00,
            stockQuantity = 300,
            minStockAlert = 50,
            batchNumber = "CV-889",
            expiryDate = "2027-07-31",
            barcode = "894110010100",
            shelfLocation = "Rack A-3"
        ),
        MedicineEntity(
            name = "Entacyd Plus",
            genericName = "Magaldrate + Simethicone",
            company = "Square Pharmaceuticals Ltd.",
            category = "Syrup",
            strength = "200 ml",
            unit = "Bottle",
            purchasePrice = 85.00,
            mrpPrice = 100.00,
            stockQuantity = 35,
            minStockAlert = 10,
            batchNumber = "ENT-12",
            expiryDate = "2027-05-31",
            barcode = "894110010111",
            shelfLocation = "Syrup Rack 1"
        ),
        MedicineEntity(
            name = "Tofen Syrup",
            genericName = "Ketotifen",
            company = "Beximco Pharmaceuticals Ltd.",
            category = "Syrup",
            strength = "100 ml",
            unit = "Bottle",
            purchasePrice = 60.00,
            mrpPrice = 75.00,
            stockQuantity = 8, // Low stock demo!
            minStockAlert = 15,
            batchNumber = "TF-901",
            expiryDate = "2026-09-30", // Expiring soon demo!
            barcode = "894110010122",
            shelfLocation = "Syrup Rack 2"
        ),
        MedicineEntity(
            name = "Almex 400",
            genericName = "Albendazole",
            company = "Square Pharmaceuticals Ltd.",
            category = "Tablet",
            strength = "400 mg",
            unit = "Pcs",
            purchasePrice = 4.00,
            mrpPrice = 5.00,
            stockQuantity = 90,
            minStockAlert = 15,
            batchNumber = "ALM-44",
            expiryDate = "2028-03-31",
            barcode = "894110010133",
            shelfLocation = "Rack C-3"
        ),
        MedicineEntity(
            name = "Flagyl 400",
            genericName = "Metronidazole",
            company = "Sanofi Bangladesh",
            category = "Tablet",
            strength = "400 mg",
            unit = "Pcs",
            purchasePrice = 2.00,
            mrpPrice = 2.50,
            stockQuantity = 220,
            minStockAlert = 30,
            batchNumber = "FLG-80",
            expiryDate = "2027-08-31",
            barcode = "894110010144",
            shelfLocation = "Rack C-4"
        ),
        MedicineEntity(
            name = "Betnovate-N",
            genericName = "Betamethasone + Neomycin",
            company = "GlaxoSmithKline (GSK)",
            category = "Ointment",
            strength = "20 gm",
            unit = "Tube",
            purchasePrice = 42.00,
            mrpPrice = 52.00,
            stockQuantity = 40,
            minStockAlert = 10,
            batchNumber = "BTN-31",
            expiryDate = "2027-06-30",
            barcode = "894110010155",
            shelfLocation = "Ointment Rack"
        )
    )

    val initialCustomers = listOf(
        CustomerEntity(
            name = "মোঃ রফিকুল ইসলাম",
            phone = "01711223344",
            address = "সোনাখালী, আমতলী",
            totalPurchases = 4500.0,
            currentDue = 650.0
        ),
        CustomerEntity(
            name = "অনিল কুমার শীল",
            phone = "01722334455",
            address = "চৌরাস্তা, আমতলী",
            totalPurchases = 2800.0,
            currentDue = 320.0
        ),
        CustomerEntity(
            name = "সুজন হাওলাদার",
            phone = "01733445566",
            address = "পশ্চিম সোনাখালী",
            totalPurchases = 6100.0,
            currentDue = 1100.0
        ),
        CustomerEntity(
            name = "আব্দুর রহমান মোল্লা",
            phone = "01819556677",
            address = "আমতলী বাজার",
            totalPurchases = 1200.0,
            currentDue = 0.0
        )
    )

    val initialSuppliers = listOf(
        SupplierEntity(
            companyName = "স্কয়ার ফার্মাসিউটিক্যালস (ডিপো)",
            representativeName = "মোস্তাফিজুর রহমান (MPO)",
            phone = "01715001122",
            address = "বরগুনা জেলা ডিপো",
            currentDue = 8500.0,
            totalPurchased = 45000.0
        ),
        SupplierEntity(
            companyName = "বেক্সিমকো ফার্মা (আমতলী এজেন্সি)",
            representativeName = "তানভীর আহমেদ (SR)",
            phone = "01716002233",
            address = "আমতলী থানা মোড়",
            currentDue = 4200.0,
            totalPurchased = 32000.0
        ),
        SupplierEntity(
            companyName = "ইনসেপ্টা ফার্মাসিউটিক্যালস",
            representativeName = "কামাল হোসেন",
            phone = "01717003344",
            address = "পটুয়াখালী রোড, বরগুনা",
            currentDue = 0.0,
            totalPurchased = 18500.0
        ),
        SupplierEntity(
            companyName = "রেনেটা লিমিটেড",
            representativeName = "জাকির হোসেন",
            phone = "01718004455",
            address = "বরগুনা সদর",
            currentDue = 3100.0,
            totalPurchased = 15000.0
        )
    )

    val initialStaff = listOf(
        StaffUserEntity(
            name = "প্রদীপ চন্দ্র হাওলাদার",
            role = "Owner / Admin",
            phone = "01739097390",
            pinCode = "1234",
            isActive = true
        ),
        StaffUserEntity(
            name = "তাপস হাওলাদার",
            role = "Pharmacist",
            phone = "01799887766",
            pinCode = "2233",
            isActive = true
        )
    )

    val medicineCategories = listOf(
        "All",
        "Tablet",
        "Capsule",
        "Syrup",
        "Injection",
        "Ointment",
        "Eye Drop",
        "Suspension",
        "Inhaler",
        "Suppository",
        "Other"
    )

    val expenseCategories = listOf(
        "দোকান ভাড়া (Shop Rent)",
        "বিদ্যুৎ বিল (Electricity Bill)",
        "কর্মচারী বেতন (Staff Salary)",
        "যাতায়াত খরচ (Transport)",
        "চা ও নাস্তা (Tea & Snacks)",
        "মেরামত ও পরিচ্ছন্নতা (Maintenance)",
        "অন্যান্য খরচ (Other Expense)"
    )
}
