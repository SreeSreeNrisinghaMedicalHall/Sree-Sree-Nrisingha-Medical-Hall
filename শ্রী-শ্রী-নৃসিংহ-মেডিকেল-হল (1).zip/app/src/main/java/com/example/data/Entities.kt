package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "medicines")
data class MedicineEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val genericName: String,
    val company: String,
    val category: String, // Tablet, Capsule, Syrup, Injection, Ointment, Drop, Suspension, Inhaler
    val strength: String, // 500mg, 20mg, 10ml, etc.
    val unit: String = "Pcs", // Pcs, Strip, Box, Bottle
    val purchasePrice: Double,
    val mrpPrice: Double,
    val stockQuantity: Int,
    val minStockAlert: Int = 20,
    val batchNumber: String = "B-2026A",
    val expiryDate: String = "2027-12-31", // YYYY-MM-DD
    val barcode: String = "",
    val shelfLocation: String = "Rack A-1",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "customers")
data class CustomerEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val phone: String,
    val address: String = "",
    val totalPurchases: Double = 0.0,
    val currentDue: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "suppliers")
data class SupplierEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val companyName: String,
    val representativeName: String = "",
    val phone: String = "",
    val address: String = "",
    val currentDue: Double = 0.0,
    val totalPurchased: Double = 0.0,
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "sales_invoices")
data class SaleInvoiceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val invoiceNumber: String,
    val customerName: String = "সাধারণ ক্রেতা (Walk-in)",
    val customerPhone: String = "",
    val customerId: Long? = null,
    val subtotal: Double,
    val discount: Double = 0.0,
    val discountPercent: Double = 0.0,
    val grandTotal: Double,
    val paidAmount: Double,
    val dueAmount: Double = 0.0,
    val paymentMethod: String = "Cash", // Cash, bKash/Nagad, Card, Due
    val timestamp: Long = System.currentTimeMillis(),
    val itemsJson: String = "[]",
    val totalProfit: Double = 0.0,
    val soldBy: String = "প্রদীপ চন্দ্র হাওলাদার",
    val prescriptionNote: String = ""
)

@Entity(tableName = "purchase_invoices")
data class PurchaseInvoiceEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val invoiceNumber: String,
    val supplierId: Long,
    val supplierName: String,
    val totalAmount: Double,
    val paidAmount: Double,
    val dueAmount: Double = 0.0,
    val timestamp: Long = System.currentTimeMillis(),
    val itemsJson: String = "[]",
    val note: String = ""
)

@Entity(tableName = "cash_transactions")
data class CashTransactionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // INCOME_SALE, INCOME_DUE, EXPENSE_PURCHASE, EXPENSE_SUPPLIER_PAY, EXPENSE_SHOP, OTHER_INCOME, OTHER_EXPENSE
    val category: String, // Sale, Due Collection, Purchase, Rent, Electricity, Staff Salary, Transport, Tea/Snacks, Other
    val amount: Double,
    val title: String,
    val referenceId: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val note: String = ""
)

@Entity(tableName = "return_records")
data class ReturnRecordEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val type: String, // SALE_RETURN, PURCHASE_RETURN
    val medicineId: Long,
    val medicineName: String,
    val quantity: Int,
    val unitPrice: Double,
    val totalAmount: Double,
    val partyName: String,
    val reason: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "prescription_records")
data class PrescriptionEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val patientName: String,
    val patientAge: String = "",
    val patientPhone: String = "",
    val doctorName: String = "",
    val hospitalClinic: String = "",
    val medicinesPrescribed: String = "",
    val notes: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "staff_users")
data class StaffUserEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val name: String,
    val role: String, // Owner / Admin, Manager, Pharmacist, Salesman
    val phone: String = "",
    val pinCode: String = "1234",
    val isActive: Boolean = true
)

// Data Models for JSON items in invoices
data class CartItem(
    val medicineId: Long,
    val name: String,
    val genericName: String,
    val strength: String,
    val unit: String,
    val unitPrice: Double,
    val purchasePrice: Double,
    val quantity: Int,
    val stockAvailable: Int,
    val batchNumber: String = "",
    val expiryDate: String = ""
) {
    val totalPrice: Double get() = unitPrice * quantity
    val totalProfit: Double get() = (unitPrice - purchasePrice) * quantity
}
