package com.example.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface PharmacyDao {

    // --- Medicines ---
    @Query("SELECT * FROM medicines ORDER BY name ASC")
    fun getAllMedicines(): Flow<List<MedicineEntity>>

    @Query("SELECT * FROM medicines WHERE id = :id LIMIT 1")
    suspend fun getMedicineById(id: Long): MedicineEntity?

    @Query("SELECT * FROM medicines WHERE stockQuantity <= minStockAlert ORDER BY stockQuantity ASC")
    fun getLowStockMedicines(): Flow<List<MedicineEntity>>

    @Query("SELECT * FROM medicines WHERE name LIKE '%' || :query || '%' OR genericName LIKE '%' || :query || '%' OR company LIKE '%' || :query || '%' OR barcode LIKE '%' || :query || '%' ORDER BY name ASC")
    fun searchMedicines(query: String): Flow<List<MedicineEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMedicine(medicine: MedicineEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllMedicines(medicines: List<MedicineEntity>)

    @Update
    suspend fun updateMedicine(medicine: MedicineEntity)

    @Query("UPDATE medicines SET stockQuantity = stockQuantity - :qty WHERE id = :medicineId")
    suspend fun deductStock(medicineId: Long, qty: Int)

    @Query("UPDATE medicines SET stockQuantity = stockQuantity + :qty WHERE id = :medicineId")
    suspend fun addStock(medicineId: Long, qty: Int)

    @Delete
    suspend fun deleteMedicine(medicine: MedicineEntity)

    @Query("SELECT COUNT(*) FROM medicines")
    suspend fun getMedicineCount(): Int

    // --- Customers ---
    @Query("SELECT * FROM customers ORDER BY name ASC")
    fun getAllCustomers(): Flow<List<CustomerEntity>>

    @Query("SELECT * FROM customers WHERE id = :id LIMIT 1")
    suspend fun getCustomerById(id: Long): CustomerEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCustomer(customer: CustomerEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCustomers(customers: List<CustomerEntity>)

    @Update
    suspend fun updateCustomer(customer: CustomerEntity)

    @Query("UPDATE customers SET currentDue = currentDue + :dueAmount, totalPurchases = totalPurchases + :purchaseAmount WHERE id = :customerId")
    suspend fun updateCustomerPurchase(customerId: Long, purchaseAmount: Double, dueAmount: Double)

    @Query("UPDATE customers SET currentDue = currentDue - :payAmount WHERE id = :customerId")
    suspend fun deductCustomerDue(customerId: Long, payAmount: Double)

    @Delete
    suspend fun deleteCustomer(customer: CustomerEntity)

    // --- Suppliers ---
    @Query("SELECT * FROM suppliers ORDER BY companyName ASC")
    fun getAllSuppliers(): Flow<List<SupplierEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSupplier(supplier: SupplierEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSuppliers(suppliers: List<SupplierEntity>)

    @Update
    suspend fun updateSupplier(supplier: SupplierEntity)

    @Query("UPDATE suppliers SET currentDue = currentDue + :dueAmount, totalPurchased = totalPurchased + :purchaseAmount WHERE id = :supplierId")
    suspend fun updateSupplierPurchase(supplierId: Long, purchaseAmount: Double, dueAmount: Double)

    @Query("UPDATE suppliers SET currentDue = currentDue - :payAmount WHERE id = :supplierId")
    suspend fun deductSupplierDue(supplierId: Long, payAmount: Double)

    @Delete
    suspend fun deleteSupplier(supplier: SupplierEntity)

    // --- Sales Invoices ---
    @Query("SELECT * FROM sales_invoices ORDER BY timestamp DESC")
    fun getAllSales(): Flow<List<SaleInvoiceEntity>>

    @Query("SELECT * FROM sales_invoices WHERE timestamp >= :startTime AND timestamp <= :endTime ORDER BY timestamp DESC")
    fun getSalesBetween(startTime: Long, endTime: Long): Flow<List<SaleInvoiceEntity>>

    @Query("SELECT * FROM sales_invoices WHERE customerId = :customerId ORDER BY timestamp DESC")
    fun getSalesByCustomer(customerId: Long): Flow<List<SaleInvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSale(sale: SaleInvoiceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSales(sales: List<SaleInvoiceEntity>)

    @Delete
    suspend fun deleteSale(sale: SaleInvoiceEntity)

    // --- Purchase Invoices ---
    @Query("SELECT * FROM purchase_invoices ORDER BY timestamp DESC")
    fun getAllPurchases(): Flow<List<PurchaseInvoiceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPurchase(purchase: PurchaseInvoiceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllPurchases(purchases: List<PurchaseInvoiceEntity>)

    // --- Cash Transactions ---
    @Query("SELECT * FROM cash_transactions ORDER BY timestamp DESC")
    fun getAllCashTransactions(): Flow<List<CashTransactionEntity>>

    @Query("SELECT * FROM cash_transactions WHERE timestamp >= :startTime AND timestamp <= :endTime ORDER BY timestamp DESC")
    fun getCashTransactionsBetween(startTime: Long, endTime: Long): Flow<List<CashTransactionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCashTransaction(transaction: CashTransactionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCashTransactions(transactions: List<CashTransactionEntity>)

    @Delete
    suspend fun deleteCashTransaction(transaction: CashTransactionEntity)

    // --- Return Records ---
    @Query("SELECT * FROM return_records ORDER BY timestamp DESC")
    fun getAllReturns(): Flow<List<ReturnRecordEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReturn(returnRecord: ReturnRecordEntity): Long

    // --- Prescriptions ---
    @Query("SELECT * FROM prescription_records ORDER BY timestamp DESC")
    fun getAllPrescriptions(): Flow<List<PrescriptionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertPrescription(prescription: PrescriptionEntity): Long

    @Delete
    suspend fun deletePrescription(prescription: PrescriptionEntity)

    // --- Staff Users ---
    @Query("SELECT * FROM staff_users ORDER BY id ASC")
    fun getAllStaff(): Flow<List<StaffUserEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertStaff(staff: StaffUserEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllStaff(staffList: List<StaffUserEntity>)

    @Delete
    suspend fun deleteStaff(staff: StaffUserEntity)

    // Raw clear for database restore
    @Query("DELETE FROM medicines")
    suspend fun clearMedicines()

    @Query("DELETE FROM customers")
    suspend fun clearCustomers()

    @Query("DELETE FROM suppliers")
    suspend fun clearSuppliers()

    @Query("DELETE FROM sales_invoices")
    suspend fun clearSales()

    @Query("DELETE FROM purchase_invoices")
    suspend fun clearPurchases()

    @Query("DELETE FROM cash_transactions")
    suspend fun clearCashTransactions()
}
