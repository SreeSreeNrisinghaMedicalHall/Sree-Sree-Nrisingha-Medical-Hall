package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.ReceiptDialog
import com.example.ui.screens.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.AppScreen
import com.example.ui.viewmodel.PharmacyViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val viewModel: PharmacyViewModel = viewModel()
                PharmacyAppRoot(viewModel = viewModel)
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PharmacyAppRoot(
    viewModel: PharmacyViewModel
) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                modifier = Modifier.width(320.dp),
                drawerContainerColor = MaterialTheme.colorScheme.surface
            ) {
                // Drawer Header
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(EmeraldDark)
                        .padding(20.dp)
                ) {
                    Column {
                        Box(
                            modifier = Modifier
                                .size(50.dp)
                                .clip(CircleShape)
                                .background(Color.White.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalPharmacy,
                                contentDescription = null,
                                tint = Color.White,
                                modifier = Modifier.size(30.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "শ্রী শ্রী নৃসিংহ মেডিকেল হল",
                            style = MaterialTheme.typography.titleMedium.copy(
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        )
                        Text(
                            text = "প্রো: প্রদীপ চন্দ্র হাওলাদার (০১৭৩৯০৯৭৩৯০)",
                            style = MaterialTheme.typography.bodySmall.copy(
                                color = Color.White.copy(alpha = 0.9f)
                            )
                        )
                        Text(
                            text = "সোনাখালী, আমতলী, বরগুনা",
                            style = MaterialTheme.typography.labelSmall.copy(
                                color = Color.White.copy(alpha = 0.75f)
                            )
                        )
                    }
                }

                HorizontalDivider(color = DividerColor)

                // Drawer Navigation Items
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    DrawerItem(
                        icon = Icons.Default.Dashboard,
                        label = "ড্যাশবোর্ড (Dashboard)",
                        selected = viewModel.currentScreen == AppScreen.DASHBOARD,
                        onClick = {
                            viewModel.navigateTo(AppScreen.DASHBOARD)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.PointOfSale,
                        label = "POS বিক্রয় কাউন্টার",
                        selected = viewModel.currentScreen == AppScreen.POS_SALE,
                        badge = if (viewModel.cart.isNotEmpty()) "${viewModel.cart.size}" else null,
                        onClick = {
                            viewModel.navigateTo(AppScreen.POS_SALE)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.Medication,
                        label = "ঔষধ ইনভেন্টরি ও স্টক",
                        selected = viewModel.currentScreen == AppScreen.MEDICINES,
                        onClick = {
                            viewModel.stockTabFilter = "ALL"
                            viewModel.navigateTo(AppScreen.MEDICINES)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.AddShoppingCart,
                        label = "কোম্পানি চালান / ক্রয়",
                        selected = viewModel.currentScreen == AppScreen.PURCHASE,
                        onClick = {
                            viewModel.navigateTo(AppScreen.PURCHASE)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.PeopleAlt,
                        label = "কাস্টমার বাকি খাতা",
                        selected = viewModel.currentScreen == AppScreen.CUSTOMERS,
                        onClick = {
                            viewModel.navigateTo(AppScreen.CUSTOMERS)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.LocalShipping,
                        label = "সাপ্লায়ার / মহাজন লেজার",
                        selected = viewModel.currentScreen == AppScreen.SUPPLIERS,
                        onClick = {
                            viewModel.navigateTo(AppScreen.SUPPLIERS)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.AccountBalance,
                        label = "ক্যাশ বুক ও খরচ (Accounting)",
                        selected = viewModel.currentScreen == AppScreen.ACCOUNTING,
                        onClick = {
                            viewModel.navigateTo(AppScreen.ACCOUNTING)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.AssignmentReturn,
                        label = "ফেরত লগ (Returns)",
                        selected = viewModel.currentScreen == AppScreen.RETURNS,
                        onClick = {
                            viewModel.navigateTo(AppScreen.RETURNS)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.Assignment,
                        label = "প্রেসক্রিপশন রেকর্ড",
                        selected = viewModel.currentScreen == AppScreen.PRESCRIPTIONS,
                        onClick = {
                            viewModel.navigateTo(AppScreen.PRESCRIPTIONS)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.Assessment,
                        label = "আর্থিক রিপোর্ট ও লাভ",
                        selected = viewModel.currentScreen == AppScreen.REPORTS,
                        onClick = {
                            viewModel.navigateTo(AppScreen.REPORTS)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                    DrawerItem(
                        icon = Icons.Default.Security,
                        label = "ডাটা ব্যাকআপ ও সুরক্ষা",
                        selected = viewModel.currentScreen == AppScreen.BACKUP_SETTINGS,
                        onClick = {
                            viewModel.navigateTo(AppScreen.BACKUP_SETTINGS)
                            coroutineScope.launch { drawerState.close() }
                        }
                    )
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                CenterAlignedTopAppBar(
                    title = {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "শ্রী শ্রী নৃসিংহ মেডিকেল হল",
                                style = MaterialTheme.typography.titleMedium.copy(
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 17.sp
                                ),
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = when (viewModel.currentScreen) {
                                    AppScreen.DASHBOARD -> "ফার্মেসি ম্যানেজমেন্ট ড্যাশবোর্ড"
                                    AppScreen.POS_SALE -> "POS বিক্রয় ও ক্যাশ মেমো"
                                    AppScreen.MEDICINES -> "ঔষধ ইনভেন্টরি ও স্টক"
                                    AppScreen.PURCHASE -> "কোম্পানি চালান ও ক্রয়"
                                    AppScreen.CUSTOMERS -> "কাস্টমার বাকি খাতা (Ledger)"
                                    AppScreen.SUPPLIERS -> "সাপ্লায়ার ও মহাজন লেজার"
                                    AppScreen.ACCOUNTING -> "দৈনিক ক্যাশ বুক ও হিসাব"
                                    AppScreen.RETURNS -> "বিক্রয় ও ক্রয় ফেরত"
                                    AppScreen.PRESCRIPTIONS -> "প্রেসক্রিপশন রেজিস্ট্রি"
                                    AppScreen.REPORTS -> "আর্থিক ও বিক্রয় রিপোর্ট"
                                    AppScreen.BACKUP_SETTINGS -> "ডাটা রিকভারি ও ব্যাকআপ"
                                },
                                style = MaterialTheme.typography.labelSmall.copy(
                                    color = TextSecondary,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = {
                            coroutineScope.launch { drawerState.open() }
                        }) {
                            Icon(imageVector = Icons.Default.Menu, contentDescription = "Open Menu", tint = EmeraldPrimary)
                        }
                    },
                    actions = {
                        if (viewModel.currentScreen != AppScreen.POS_SALE) {
                            IconButton(onClick = { viewModel.navigateTo(AppScreen.POS_SALE) }) {
                                BadgedBox(
                                    badge = {
                                        if (viewModel.cart.isNotEmpty()) {
                                            Badge { Text("${viewModel.cart.size}") }
                                        }
                                    }
                                ) {
                                    Icon(imageVector = Icons.Default.PointOfSale, contentDescription = "POS", tint = EmeraldPrimary)
                                }
                            }
                        }
                        IconButton(onClick = { viewModel.triggerCloudSync() }) {
                            Icon(imageVector = Icons.Default.CloudSync, contentDescription = "Sync", tint = CyanAccent)
                        }
                    },
                    colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface
                    )
                )
            },
            bottomBar = {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    border = androidx.compose.foundation.BorderStroke(1.dp, CardBorderColor),
                    shadowElevation = 4.dp
                ) {
                    NavigationBar(
                        containerColor = MaterialTheme.colorScheme.surface,
                        tonalElevation = 0.dp
                    ) {
                        NavigationBarItem(
                            selected = viewModel.currentScreen == AppScreen.DASHBOARD,
                            onClick = { viewModel.navigateTo(AppScreen.DASHBOARD) },
                            icon = { Icon(Icons.Default.Home, contentDescription = "Dashboard") },
                            label = { Text("হোম", fontWeight = if (viewModel.currentScreen == AppScreen.DASHBOARD) FontWeight.Bold else FontWeight.Normal, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PharmacyGreenPrimary,
                                selectedTextColor = PharmacyGreenPrimary,
                                indicatorColor = PharmacyGreenContainer,
                                unselectedIconColor = TextTertiary,
                                unselectedTextColor = TextTertiary
                            )
                        )
                        NavigationBarItem(
                            selected = viewModel.currentScreen == AppScreen.MEDICINES,
                            onClick = {
                                viewModel.stockTabFilter = "ALL"
                                viewModel.navigateTo(AppScreen.MEDICINES)
                            },
                            icon = { Icon(Icons.Default.Medication, contentDescription = "Inventory") },
                            label = { Text("ঔষধ", fontWeight = if (viewModel.currentScreen == AppScreen.MEDICINES) FontWeight.Bold else FontWeight.Normal, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PharmacyGreenPrimary,
                                selectedTextColor = PharmacyGreenPrimary,
                                indicatorColor = PharmacyGreenContainer,
                                unselectedIconColor = TextTertiary,
                                unselectedTextColor = TextTertiary
                            )
                        )
                        NavigationBarItem(
                            selected = viewModel.currentScreen == AppScreen.POS_SALE,
                            onClick = { viewModel.navigateTo(AppScreen.POS_SALE) },
                            icon = {
                                BadgedBox(
                                    badge = {
                                        if (viewModel.cart.isNotEmpty()) {
                                            Badge(containerColor = RedAlert) { Text("${viewModel.cart.size}") }
                                        }
                                    }
                                ) {
                                    Icon(Icons.Default.AddShoppingCart, contentDescription = "POS")
                                }
                            },
                            label = { Text("POS বিক্রয়", fontWeight = if (viewModel.currentScreen == AppScreen.POS_SALE) FontWeight.Bold else FontWeight.Normal, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PharmacyGreenPrimary,
                                selectedTextColor = PharmacyGreenPrimary,
                                indicatorColor = PharmacyGreenContainer,
                                unselectedIconColor = TextTertiary,
                                unselectedTextColor = TextTertiary
                            )
                        )
                        NavigationBarItem(
                            selected = viewModel.currentScreen == AppScreen.REPORTS,
                            onClick = { viewModel.navigateTo(AppScreen.REPORTS) },
                            icon = { Icon(Icons.Default.Receipt, contentDescription = "Receipt") },
                            label = { Text("রসিদ", fontWeight = if (viewModel.currentScreen == AppScreen.REPORTS) FontWeight.Bold else FontWeight.Normal, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PharmacyGreenPrimary,
                                selectedTextColor = PharmacyGreenPrimary,
                                indicatorColor = PharmacyGreenContainer,
                                unselectedIconColor = TextTertiary,
                                unselectedTextColor = TextTertiary
                            )
                        )
                        NavigationBarItem(
                            selected = viewModel.currentScreen == AppScreen.BACKUP_SETTINGS,
                            onClick = { viewModel.navigateTo(AppScreen.BACKUP_SETTINGS) },
                            icon = { Icon(Icons.Default.Settings, contentDescription = "Setting") },
                            label = { Text("সেটিং", fontWeight = if (viewModel.currentScreen == AppScreen.BACKUP_SETTINGS) FontWeight.Bold else FontWeight.Normal, fontSize = 10.sp) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = PharmacyGreenPrimary,
                                selectedTextColor = PharmacyGreenPrimary,
                                indicatorColor = PharmacyGreenContainer,
                                unselectedIconColor = TextTertiary,
                                unselectedTextColor = TextTertiary
                            )
                        )
                    }
                }
            }
        ) { innerPadding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
                    .background(SlateBackground)
            ) {
                when (viewModel.currentScreen) {
                    AppScreen.DASHBOARD -> DashboardScreen(viewModel = viewModel)
                    AppScreen.POS_SALE -> PosSaleScreen(viewModel = viewModel)
                    AppScreen.MEDICINES -> MedicineListScreen(viewModel = viewModel)
                    AppScreen.PURCHASE -> PurchaseScreen(viewModel = viewModel)
                    AppScreen.CUSTOMERS -> CustomerLedgerScreen(viewModel = viewModel)
                    AppScreen.SUPPLIERS -> SupplierLedgerScreen(viewModel = viewModel)
                    AppScreen.ACCOUNTING -> AccountingScreen(viewModel = viewModel)
                    AppScreen.RETURNS -> ReturnsScreen(viewModel = viewModel)
                    AppScreen.PRESCRIPTIONS -> PrescriptionsScreen(viewModel = viewModel)
                    AppScreen.REPORTS -> ReportsScreen(viewModel = viewModel)
                    AppScreen.BACKUP_SETTINGS -> BackupSettingsScreen(viewModel = viewModel)
                }
            }
        }
    }

    // Receipt Memo Popup
    if (viewModel.showReceiptModal && viewModel.lastCompletedInvoice != null) {
        ReceiptDialog(
            invoice = viewModel.lastCompletedInvoice!!,
            cartItems = viewModel.lastCompletedCartItems,
            onDismiss = { viewModel.showReceiptModal = false }
        )
    }
}

@Composable
private fun DrawerItem(
    icon: ImageVector,
    label: String,
    selected: Boolean,
    badge: String? = null,
    onClick: () -> Unit
) {
    NavigationDrawerItem(
        icon = { Icon(imageVector = icon, contentDescription = label) },
        label = { Text(label, fontSize = 14.sp) },
        badge = if (badge != null) {
            { Badge { Text(badge) } }
        } else null,
        selected = selected,
        onClick = onClick,
        modifier = Modifier.padding(vertical = 2.dp),
        colors = NavigationDrawerItemDefaults.colors(
            selectedContainerColor = EmeraldContainer,
            selectedIconColor = EmeraldPrimary,
            selectedTextColor = EmeraldDark
        ),
        shape = RoundedCornerShape(10.dp)
    )
}
